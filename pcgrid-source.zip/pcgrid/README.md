# PCGrid — private compute worker USB prototype

PCGrid is a small, original Linux compute-worker platform. A coordinator queues
jobs, trusted PCs claim work, and each job executes in a new restricted Docker
container. The live-image configuration targets x86-64 PCs with NVIDIA RTX 30,
40, and 50 series GPUs, using Debian 13 and NVIDIA's open kernel driver.

This is an early private-network prototype, not a production replacement for
Salad. There is no public marketplace, payment system, desktop GUI, model store,
or external job ingress. The coordinator and workers are separate programs; the
USB boots a worker, not an automatically deployed cloud service.

The [hardware guide](docs/HARDWARE_SUPPORT.md) includes the HP ENVY's RTX 3050
4 GB laptop profile, AC-power protection, CPU-only configurations, and the
remaining work for Intel/AMD GPU acceleration. Wider discovery does not make
every GPU a CUDA device. Public arbitrary-code jobs remain unsupported; see
the [public-job security boundary](docs/PUBLIC_JOBS_SECURITY.md).

For a known job that waits until you boot the worker, use the
[experimental startup demo](examples/startup_job/README.md). It includes a
verified CPU calculation and an optional real CUDA calculation, with a helper
that prepares credentials and queues the first job. Use the updated USB image
and import the new worker configuration; older images cannot enforce laptop
profiles or the AC-power policy.

## What it does

- Separate worker credentials and a distinct administrator credential.
- Durable SQLite job queue; authenticated claims, renewable leases, bounded
  retries after disconnection, rejection of stale results.
- GPU-aware dispatch and per-worker CPU, RAM, and timeout limits.
- Approved container images pinned by SHA-256 digest on both coordinator and
  worker. Each job specifies an executable and arguments inside that image.
- Fresh containers with no job networking, read-only root filesystems, an
  unprivileged container user, dropped capabilities, no host directory mounts,
  bounded logs, and CPU/RAM/PID/time limits.
- NVIDIA GPU access only when both the worker and job explicitly enable it.
- CLI submission and retrieval of exit codes and bounded stdout/stderr.
- USB live-image build and provisioning instructions under [image/](image/).

## Try it on an existing Linux machine

Requirements: Python 3.11+, Docker Engine with a working daemon and sufficient
permissions for your account. GPU jobs additionally need a compatible NVIDIA
driver and NVIDIA Container Toolkit. Neither is needed for the CPU smoke test.

Run these commands from the checkout directory. Each cloud task already has an
isolated checkout: use that checkout rather than creating a Git worktree.

The sample below uses a Debian image retrieved and checked during development.
Pulling by digest checks the content identity; review a new image before adding
it to your allowlist.

```sh
IMAGE=docker.io/library/debian@sha256:62bd423aeee912639ca8ee681c2b762cb3e25137e0a92b20be455898a9f034ad
docker pull "$IMAGE"
python3 -m pcgrid.manage init --directory .local --image "$IMAGE"
python3 -m pcgrid.manage add-worker --directory .local --id pc1
python3 -m pcgrid.coordinator --config .local/coordinator.json
```

In a second terminal, in the same checkout:

```sh
python3 -m pcgrid.worker --config .local/pc1.json
```

In a third terminal:

```sh
python3 -m pcgrid.manage submit -- /bin/sh -c 'id; printf "hello from the worker\n"'
python3 -m pcgrid.manage jobs
python3 -m pcgrid.manage status JOB_ID
```

Each initialization creates private credential files without overwriting
existing files. Do not commit or publish `.local/`. Add all workers before
starting the coordinator, or restart it after adding a worker: configuration
is loaded at startup. Do not share one worker credential between PCs.

## Multiple PCs and the USB image

See [image/README.md](image/README.md) for building, booting, and configuring the
live USB. The image has no embedded worker tokens. Provision each PC with its
own worker configuration. By default, the live session is ephemeral: changes,
cached images, and credentials disappear after reboot.

While booted from this USB, the PC is a dedicated Linux worker. Its installed
Windows or Linux desktop is not running alongside it. Reboot into the installed
OS to use the PC normally.
Keep the boot USB connected until shutdown. The separate configuration USB can
be removed after import finishes.

Keep the coordinator on a reachable machine. For connections across machines,
put it behind a properly configured HTTPS reverse proxy with a certificate
trusted by the workers. Workers initiate outbound connections, so contributors
do not need to forward inbound ports on home routers.

For your first two-PC test on one trusted home network, follow
[the LAN quickstart](docs/LAN_QUICKSTART.md). It includes explicit lab-only HTTP
configuration and does not require an external hosting account.

Example when the coordinator's HTTPS endpoint is available:

```sh
python3 -m pcgrid.manage add-worker --directory .local --id gpu-pc1 \
  --url https://compute.example.org --gpu
```

Transfer only `.local/gpu-pc1.json` privately to that machine; never transfer
`coordinator.json`. The worker's local configuration can set `max_cpus`
(default 2), `max_memory_mb` (2048), and `max_timeout_seconds` (3600).
Restart the coordinator after registering the worker.

For a trusted lab LAN only, a worker can explicitly enable plaintext HTTP using
`--allow-insecure-http` when creating its configuration. This exposes bearer
credentials to anyone able to observe that network. Admin CLI requests require
HTTPS outside loopback; administer a lab HTTP server locally or through an SSH
tunnel. No TLS verification bypass is provided.

## NVIDIA job check

On the worker, first verify `nvidia-smi`, then verify Docker GPU access using an
approved CUDA image compatible with the GPU. RTX 5090 needs a sufficiently new
driver **and** workload libraries compiled for Blackwell; a new host driver
alone does not make every older ML image compatible.

Review and pull the chosen CUDA image, resolve its immutable repository digest
with `docker image inspect`, and add that exact digest to `allowed_images` in
both coordinator and worker configurations. Restart both services. Submit:

```sh
python3 -m pcgrid.manage submit --image YOUR_APPROVED_IMAGE_AT_SHA256_DIGEST \
  --gpu -- /usr/bin/nvidia-smi
```

Use a real `registry/repository@sha256:...` value for that placeholder. Do not
remove digest checks to make a mutable image tag work. This smoke check proves
device visibility; validate an actual CUDA workload on each GPU family before
claiming application compatibility. Jobs have no network access: package model
files and dependencies into the approved workload image ahead of time.

## Validate

```sh
python3 -m unittest discover -v
python3 scripts/smoke_test.py --image "$IMAGE"
```

The smoke test starts its own coordinator, exercises the real Docker worker,
and checks successful execution, isolation properties, failed executables, and
timeouts, lease renewal, and recovery after a worker interruption. It does not
require or claim to test an NVIDIA GPU. See
[docs/VALIDATION.md](docs/VALIDATION.md) for the checks actually executed.

## Scope and trust

Use trusted participants and nonsensitive workloads. Containers share the
host's kernel; exposing a GPU also exposes its driver. A contributor with
control of the host can inspect the workload and falsify results. This project
does not solve hostile-host confidentiality or provide a safe public arbitrary
code service. Keep Docker and the OS updated; Docker access is a host-level
privilege, so only trusted administrators should provision workers.

GPU jobs intentionally receive NVIDIA devices and runtime-injected driver
components. The restriction on host mounts means jobs cannot request access to
your personal folders or the Docker socket.

One job runs per worker at a time. A lost lease can cause a job to execute again;
design workloads without external side effects. Results are bounded textual
output, not large file artifacts. GPU jobs currently expose all GPUs on a
worker and have no enforceable VRAM, power, or fair-sharing quota. There is no
automatic coordinator discovery, public enrollment, fleet update service,
artifact storage, accounting ledger, payment integration, or availability SLA.

Project code is MIT-licensed. Linux, Debian packages, NVIDIA components, and
other bundled software retain their own licenses and notices. Review the
bundled components' redistribution terms before public distribution.
