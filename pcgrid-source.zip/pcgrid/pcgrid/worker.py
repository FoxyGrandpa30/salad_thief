"""Outbound Linux worker for a small, trusted PCGrid installation.

Container restrictions reduce accidental exposure; they are not a security
boundary suitable for arbitrary hostile workloads on a personal computer.
"""

from __future__ import annotations

import argparse
import hashlib
import ipaddress
import json
import logging
import http.client
import os
from pathlib import Path
import re
import signal
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid


LOG = logging.getLogger("pcgrid.worker")
IMAGE_RE = re.compile(r"[a-z0-9][a-z0-9._:/-]*@sha256:[0-9a-f]{64}\Z")
ID_RE = re.compile(r"[A-Za-z0-9_-]{1,128}\Z")
OUTPUT_BYTES = 8192


class WorkerError(Exception):
    """An actionable, credential-free worker error."""


class LeaseLost(WorkerError):
    pass


class RuntimeTimeout(WorkerError):
    pass


class CleanupError(WorkerError):
    pass


def _number(value, low, high, name, *, integer=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise WorkerError(f"{name} must be a number")
    if integer and not isinstance(value, int):
        raise WorkerError(f"{name} must be an integer")
    if not low <= value <= high:
        raise WorkerError(f"{name} is outside supported limits")
    return value


def validate_config(raw):
    if not isinstance(raw, dict):
        raise WorkerError("worker configuration must be a JSON object")
    config = dict(raw)
    url = config.get("coordinator_url")
    if not isinstance(url, str):
        raise WorkerError("coordinator_url is required")
    try:
        parsed = urllib.parse.urlsplit(url)
        _ = parsed.port
    except ValueError as exc:
        raise WorkerError("coordinator_url is invalid") from exc
    if (parsed.scheme not in ("http", "https") or not parsed.hostname
            or parsed.username is not None or parsed.password is not None
            or parsed.query or parsed.fragment or parsed.path not in ("", "/")):
        raise WorkerError("coordinator_url must be an HTTP(S) origin without credentials or a path")
    for flag in ("allow_insecure_http", "gpu_enabled", "require_ac_power"):
        if not isinstance(config.get(flag, False), bool):
            raise WorkerError(f"{flag} must be a boolean")
        config.setdefault(flag, False)
    try:
        loopback = ipaddress.ip_address(parsed.hostname).is_loopback
    except ValueError:
        loopback = parsed.hostname.lower() == "localhost"
    if parsed.scheme == "http" and not loopback and not config["allow_insecure_http"]:
        raise WorkerError("remote coordinator requires HTTPS; trusted LAN testing needs explicit allow_insecure_http")
    token = config.get("worker_token")
    if (not isinstance(token, str) or not 24 <= len(token) <= 1017
            or any(not 33 <= ord(c) <= 126 for c in token)):
        raise WorkerError("worker_token must contain 24-1017 visible ASCII characters without whitespace")
    images = config.get("allowed_images")
    if (not isinstance(images, list) or not 1 <= len(images) <= 128
            or any(not isinstance(image, str) or not IMAGE_RE.fullmatch(image) for image in images)):
        raise WorkerError("allowed_images must contain approved images pinned with @sha256 digests")
    config["coordinator_url"] = url.rstrip("/")
    config["poll_seconds"] = _number(config.get("poll_seconds", 5), 0.1, 300, "poll_seconds")
    config["max_cpus"] = _number(config.get("max_cpus", 2), 0.1, 64, "max_cpus")
    config["max_memory_mb"] = _number(config.get("max_memory_mb", 2048), 32, 65536, "max_memory_mb", integer=True)
    config["max_timeout_seconds"] = _number(config.get("max_timeout_seconds", 3600), 1, 3600, "max_timeout_seconds", integer=True)
    return config


def load_config(path):
    path = Path(path)
    if os.name == "posix" and path.stat().st_mode & 0o077:
        raise WorkerError("worker configuration contains credentials: restrict it with chmod 600")
    with path.open("rb") as stream:
        data = stream.read(65537)
    if len(data) > 65536:
        raise WorkerError("worker configuration is too large")
    try:
        return validate_config(json.loads(data))
    except (ValueError, UnicodeError, RecursionError) as exc:
        raise WorkerError("worker configuration is not valid JSON") from exc


def validate_job(job, config):
    if not isinstance(job, dict):
        raise WorkerError("claimed job is not an object")
    if not isinstance(job.get("id"), str) or not ID_RE.fullmatch(job["id"]):
        raise WorkerError("invalid job identifier")
    if not isinstance(job.get("lease_token"), str) or not 1 <= len(job["lease_token"]) <= 4096:
        raise WorkerError("invalid lease token")
    if job.get("image") not in config["allowed_images"]:
        raise WorkerError("job image is not in this worker's pinned allowlist")
    command = job.get("command")
    try:
        invalid_command = (not isinstance(command, list) or not 1 <= len(command) <= 64
                           or any(not isinstance(arg, str) or "\x00" in arg or len(arg.encode("utf-8")) > 4096 for arg in command)
                           or not command[0] or sum(len(arg.encode("utf-8")) for arg in command) > 32768)
    except UnicodeError:
        invalid_command = True
    if invalid_command:
        raise WorkerError("invalid or oversized job command")
    _number(job.get("timeout_seconds"), 1, config["max_timeout_seconds"], "job timeout", integer=True)
    _number(job.get("cpus"), 0.1, config["max_cpus"], "job CPUs")
    _number(job.get("memory_mb"), 32, config["max_memory_mb"], "job memory", integer=True)
    if not isinstance(job.get("gpu", False), bool):
        raise WorkerError("job gpu must be a boolean")
    if job.get("gpu", False) and not config["gpu_enabled"]:
        raise WorkerError("GPU jobs are disabled on this worker")


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, msg, headers, newurl):
        return None


class API:
    def __init__(self, config):
        self.origin = config["coordinator_url"]
        self.token = config["worker_token"]
        # Default HTTPSHandler retains the system trust store and certificate checks.
        self.opener = urllib.request.build_opener(NoRedirect())

    def post(self, path, payload, timeout=10):
        request = urllib.request.Request(
            self.origin + path,
            data=json.dumps(payload, allow_nan=False).encode("utf-8"),
            headers={"Authorization": "Bearer " + self.token, "Content-Type": "application/json"},
            method="POST",
        )
        try:
            with self.opener.open(request, timeout=timeout) as response:
                if response.status == 204:
                    return None
                body = response.read(262145)
                if len(body) > 262144:
                    raise WorkerError("coordinator response exceeds size limit")
                return json.loads(body)
        except urllib.error.HTTPError as exc:
            raise WorkerError(f"coordinator returned HTTP {exc.code}") from None
        except (urllib.error.URLError, OSError, ValueError, RecursionError, http.client.HTTPException):
            # Do not echo exception URLs, request headers, or the credential.
            raise WorkerError("coordinator request failed; check connectivity and its service logs") from None


def _read_output(stream):
    stream.seek(0)
    data = stream.read(OUTPUT_BYTES + 1)
    text = data[:OUTPUT_BYTES].decode("utf-8", errors="replace")
    return text + ("\n[output truncated]" if len(data) > OUTPUT_BYTES else "")


def _command(argv, deadline, cancelled=None):
    """Run a Docker CLI operation without a shell or unbounded in-memory output."""
    if cancelled is not None and cancelled.is_set():
        raise LeaseLost("worker stopped or lease lost")
    if time.monotonic() >= deadline:
        raise RuntimeTimeout("job or Docker operation exceeded its timeout")
    with tempfile.TemporaryFile() as out, tempfile.TemporaryFile() as err:
        try:
            process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=out, stderr=err)
        except OSError:
            raise WorkerError("could not start Docker; check installation and socket access") from None
        try:
            while process.poll() is None:
                if cancelled is not None and cancelled.is_set():
                    raise LeaseLost("job stopped because the worker stopped or its lease was lost")
                if time.monotonic() >= deadline:
                    raise RuntimeTimeout("job or Docker operation exceeded its timeout")
                time.sleep(0.1)
            return process.returncode, _read_output(out), _read_output(err)
        finally:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=3)


def container_command(job, name, owner):
    argv = [
        "docker", "create", "--pull=missing", "--name", name,
        "--label", "pcgrid.managed=true", "--label", "pcgrid.owner=" + owner,
        "--label", "pcgrid.job=" + job["id"],
        "--network", "none", "--read-only",
        "--tmpfs", "/tmp:rw,noexec,nosuid,nodev,size=64m",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges:true",
        "--user", "65534:65534", "--pids-limit", "128",
        "--cpus", str(job["cpus"]), "--memory", str(job["memory_mb"]) + "m",
        "--memory-swap", str(job["memory_mb"]) + "m",
        "--log-driver", "local", "--log-opt", "max-size=1m", "--log-opt", "max-file=1",
        "--log-opt", "compress=false",
        "--stop-timeout", "5", "--entrypoint=" + job["command"][0],
    ]
    if job.get("gpu", False):
        argv += ["--gpus", "all"]
    return argv + [job["image"]] + job["command"][1:]


class DockerRuntime:
    def __init__(self, token):
        self.owner = hashlib.sha256(token.encode()).hexdigest()[:24]

    def cleanup_stale(self):
        code, out, _ = _command(
            ["docker", "ps", "-aq", "--filter", "label=pcgrid.owner=" + self.owner],
            time.monotonic() + 15,
        )
        if code:
            raise WorkerError("cannot reach Docker; check the daemon and socket access")
        ids = out.split()
        if any(not re.fullmatch(r"[0-9a-f]{12,64}", item) for item in ids):
            raise WorkerError("unexpected Docker container identifiers")
        if ids:
            code, _, _ = _command(["docker", "rm", "--force", "--volumes"] + ids, time.monotonic() + 20)
            if code:
                raise CleanupError("could not remove containers left by a previous worker run")

    def execute(self, job, cancelled):
        name = "pcgrid-" + uuid.uuid4().hex
        deadline = time.monotonic() + job["timeout_seconds"]
        try:
            code, _, err = _command(container_command(job, name, self.owner), deadline, cancelled)
            if code:
                raise WorkerError("Docker could not create the job container: " + err)
            code, _, err = _command(["docker", "start", name], deadline, cancelled)
            if code:
                raise WorkerError("Docker could not start the job container: " + err)
            while True:
                code, out, err = _command(
                    ["docker", "inspect", "--format", "{{.State.Running}} {{.State.ExitCode}}", name],
                    min(deadline, time.monotonic() + 10), cancelled,
                )
                if code:
                    raise WorkerError("Docker could not inspect the job container: " + err)
                fields = out.strip().split()
                if len(fields) != 2 or fields[0] not in ("true", "false"):
                    raise WorkerError("Docker returned an invalid container state")
                if fields[0] == "false":
                    try:
                        exit_code = int(fields[1])
                    except ValueError:
                        raise WorkerError("Docker returned an invalid exit status") from None
                    code, stdout, stderr = _command(
                        ["docker", "logs", "--tail", "200", name], time.monotonic() + 10, cancelled,
                    )
                    if code:
                        raise WorkerError("Docker could not retrieve the job logs")
                    return {"exit_code": exit_code, "stdout": stdout, "stderr": stderr}
                if cancelled.wait(0.2):
                    raise LeaseLost("worker stopped or lease lost")
                if time.monotonic() >= deadline:
                    raise RuntimeTimeout("job exceeded its timeout")
        except RuntimeTimeout:
            return {"exit_code": 124, "stdout": "", "stderr": "worker stopped the job after its timeout"}
        finally:
            try:
                code, _, err = _command(["docker", "rm", "--force", "--volumes", name], time.monotonic() + 20)
            except WorkerError:
                raise CleanupError("could not confirm job container cleanup; stop this worker and inspect Docker") from None
            if code and "No such container" not in err:
                raise CleanupError("could not confirm job container cleanup; stop this worker and inspect Docker")


class LeaseGuard:
    def __init__(self, api, job, shutdown, continue_running=None):
        self.api = api
        self.job = job
        self.shutdown = shutdown
        self.continue_running = continue_running
        self.cancelled = threading.Event()
        self.finished = threading.Event()
        lease_seconds = job.get("lease_seconds", 30)
        _number(lease_seconds, 1, 300, "lease_seconds")
        self.interval = min(5, lease_seconds / 3)
        self.thread = threading.Thread(target=self._run, daemon=True)

    def _cancel_requested(self):
        if self.shutdown.is_set():
            return True
        if self.continue_running is not None:
            try:
                return not self.continue_running()
            except Exception:
                # A broken local safety probe must not leave work running.
                LOG.warning("Local execution policy could not be checked; cancelling the job")
                return True
        return False

    def _run(self):
        next_heartbeat = time.monotonic() + self.interval
        while not self.finished.wait(min(0.1, self.interval)):
            if self.cancelled.is_set() or self._cancel_requested():
                self.cancelled.set()
                return
            if time.monotonic() < next_heartbeat:
                continue
            try:
                self.api.post(
                    f"/v1/jobs/{self.job['id']}/heartbeat",
                    {"lease_token": self.job["lease_token"]},
                    timeout=min(10, self.interval),
                )
            except WorkerError:
                self.cancelled.set()
                LOG.warning("Lease could not be renewed; cancelling the local job")
                return
            next_heartbeat = time.monotonic() + self.interval

    def __enter__(self):
        if self._cancel_requested():
            self.cancelled.set()
        self.thread.start()
        return self

    def __exit__(self, *args):
        self.finished.set()
        self.thread.join(timeout=11)


class Worker:
    def __init__(self, config, api=None, runtime=None, shutdown=None, power_probe=None):
        self.config = validate_config(config)
        self.api = api or API(self.config)
        self.runtime = runtime or DockerRuntime(self.config["worker_token"])
        self.shutdown = shutdown or threading.Event()
        self.power_probe = power_probe or self._read_ac_power
        self._last_ac_state = object()
        self._power_lock = threading.Lock()

    @staticmethod
    def _read_ac_power():
        # Legacy workers need no hardware module until the local policy is used.
        from pcgrid.hardware import read_ac_power
        return read_ac_power()

    def _power_allows_work(self):
        if not self.config["require_ac_power"]:
            return True
        try:
            state = self.power_probe()
        except Exception:
            # Missing hardware support and unreadable status are both unknown.
            state = None
        if state is not True and state is not False:
            state = None
        with self._power_lock:
            if state is not self._last_ac_state:
                self._last_ac_state = state
                if state is True:
                    LOG.info("AC power available; the worker can accept jobs")
                elif state is False:
                    LOG.info("AC power disconnected; pausing jobs until AC power returns")
                else:
                    LOG.warning("AC power status is unknown; pausing jobs until AC power is confirmed")
        return state is True

    def run_once(self):
        if not self._power_allows_work():
            return False
        claim = self.api.post("/v1/jobs/claim", {"capabilities": {
            "gpu": self.config["gpu_enabled"],
            "max_cpus": self.config["max_cpus"],
            "max_memory_mb": self.config["max_memory_mb"],
            "max_timeout_seconds": self.config["max_timeout_seconds"],
        }})
        if claim is None:
            return False
        job = claim.get("job") if isinstance(claim, dict) else None
        if (not isinstance(job, dict) or not isinstance(job.get("id"), str)
                or not ID_RE.fullmatch(job["id"]) or not isinstance(job.get("lease_token"), str)
                or not 1 <= len(job["lease_token"]) <= 4096):
            raise WorkerError("coordinator returned an invalid claim")
        LOG.info("Claimed job %s", job["id"])
        try:
            validate_job(job, self.config)
        except WorkerError as exc:
            result = {"exit_code": 125, "stdout": "", "stderr": str(exc)}
        else:
            policy = self._power_allows_work if self.config["require_ac_power"] else None
            with LeaseGuard(self.api, job, self.shutdown, continue_running=policy) as lease:
                if lease.cancelled.is_set():
                    return True
                try:
                    result = self.runtime.execute(job, lease.cancelled)
                except LeaseLost:
                    LOG.warning("Job %s cancelled locally; no result submitted", job["id"])
                    return True
                except CleanupError:
                    raise
                except WorkerError as exc:
                    result = {"exit_code": 125, "stdout": "", "stderr": str(exc)}
            if lease.cancelled.is_set() or self.shutdown.is_set():
                return True
        if self.shutdown.is_set() or not self._power_allows_work():
            return True
        # Bound diagnostic strings again before sending them to the coordinator.
        result["stdout"] = result["stdout"][:OUTPUT_BYTES]
        result["stderr"] = result["stderr"][:OUTPUT_BYTES]
        self.api.post(f"/v1/jobs/{job['id']}/result", {"lease_token": job["lease_token"], **result})
        LOG.info("Completed job %s with exit code %s", job["id"], result["exit_code"])
        return True

    def run(self, once=False):
        self.runtime.cleanup_stale()
        while not self.shutdown.is_set():
            try:
                self.run_once()
            except CleanupError:
                raise
            except WorkerError as exc:
                if once:
                    raise
                LOG.warning("%s", exc)
            if once:
                return
            self.shutdown.wait(self.config["poll_seconds"])


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, help="root/user-only worker JSON configuration")
    parser.add_argument("--once", action="store_true", help="claim at most one job, then exit")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    shutdown = threading.Event()
    for signum in (signal.SIGINT, signal.SIGTERM):
        signal.signal(signum, lambda *_: shutdown.set())
    try:
        # Lock the same config inode to prevent concurrent agents from killing
        # one another's containers during startup cleanup.
        import fcntl
        with open(args.config, "rb") as config_lock:
            try:
                fcntl.flock(config_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                raise WorkerError("another worker is already using this configuration") from None
            Worker(load_config(args.config), shutdown=shutdown).run(once=args.once)
        return 0
    except (WorkerError, OSError) as exc:
        LOG.error("%s", exc)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
