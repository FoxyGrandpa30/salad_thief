"""Local administration for a small, trusted PCGrid network (Python 3.11+)."""

import argparse
import json
import os
from pathlib import Path
import re
import secrets
import sys
import urllib.error
import urllib.request

from pcgrid.worker import WorkerError, validate_config


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise ValueError("Refusing an authenticated redirect")


def write_private(path, value):
    """Create a credential file without following or overwriting existing files."""
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as handle:
        json.dump(value, handle, indent=2)
        handle.write("\n")


def load(path):
    if os.name == "posix" and Path(path).stat().st_mode & 0o077:
        raise ValueError("Credential files must be private: chmod 600")
    with open(path) as handle:
        raw = handle.read(262145)
    if len(raw) > 262144:
        raise ValueError("Configuration exceeds size limit")
    return json.loads(raw)


def request(url, token, method="GET", body=None):
    data = None if body is None else json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, method=method, headers={
        "Authorization": "Bearer " + token,
        "Content-Type": "application/json",
    })
    with urllib.request.build_opener(NoRedirect).open(req, timeout=15) as response:
        raw = response.read(1_048_577)
        if len(raw) > 1_048_576:
            raise ValueError("Coordinator response exceeds limit")
        return json.loads(raw) if raw else None


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    init = sub.add_parser("init", help="create coordinator config; does not start a service")
    init.add_argument("--directory", default=".local")
    init.add_argument("--image", action="append", required=True,
                      help="approved fully qualified image@sha256:digest; repeat as needed")
    init.add_argument("--host", default="127.0.0.1")
    init.add_argument("--port", type=int, default=8080)
    add = sub.add_parser("add-worker", help="create a unique worker credential; restart coordinator afterwards")
    add.add_argument("--directory", default=".local")
    add.add_argument("--id", required=True)
    add.add_argument("--url", default="http://127.0.0.1:8080")
    add.add_argument("--gpu", action="store_true")
    add.add_argument("--profile", choices=("standard", "laptop-cpu", "laptop-nvidia"), default="standard")
    add.add_argument("--allow-insecure-http", action="store_true",
                     help="explicitly allow plaintext HTTP for a trusted lab LAN")
    for name in ("submit", "status", "jobs"):
        command = sub.add_parser(name)
        command.add_argument("--config", default=".local/coordinator.json")
        command.add_argument("--url", default="http://127.0.0.1:8080")
        if name == "submit":
            command.add_argument("--image")
            command.add_argument("--gpu", action="store_true")
            command.add_argument("--timeout", type=int, default=60)
            command.add_argument("--cpus", type=float, default=1)
            command.add_argument("--memory", type=int, default=512)
            command.add_argument("command", nargs=argparse.REMAINDER)
        if name == "status":
            command.add_argument("id")
    args = parser.parse_args(argv)
    if args.action == "init":
        for image in args.image:
            if not re.fullmatch(r"[a-z0-9][a-z0-9._/:\-]*@sha256:[0-9a-f]{64}", image):
                raise ValueError("Images must be pinned by sha256 digest")
        if not 1 <= args.port <= 65535:
            raise ValueError("Port must be between 1 and 65535")
        directory = Path(args.directory).resolve()
        directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        config = {"database": str(directory / "jobs.sqlite3"),
                  "host": args.host, "port": args.port,
                  "admin_token": secrets.token_urlsafe(32), "workers": {},
                  "allowed_images": args.image, "lease_seconds": 30}
        path = directory / "coordinator.json"
        write_private(path, config)
        print(f"Created {path}; credentials were not printed.")
    elif args.action == "add-worker":
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", args.id):
            raise ValueError("Worker id must contain 1-64 letters, numbers, underscores or hyphens")
        if args.profile == "laptop-cpu" and args.gpu:
            raise ValueError("The initial laptop profile is CPU-only; verify its adapter and backend before enabling GPU jobs")
        directory = Path(args.directory).resolve()
        path = directory / "coordinator.json"
        config = load(path)
        if args.id in config["workers"]:
            raise ValueError("Worker id already exists")
        token = secrets.token_urlsafe(32)
        worker = {"coordinator_url": args.url.rstrip("/"), "worker_token": token,
                  "allowed_images": config["allowed_images"], "gpu_enabled": args.gpu,
                  "allow_insecure_http": args.allow_insecure_http, "poll_seconds": 5}
        if args.profile != "standard":
            from pcgrid.hardware import WORKER_PROFILES
            worker.update(WORKER_PROFILES[args.profile])
            worker["device_profile"] = args.profile
        validate_config(worker)
        worker_path = directory / f"{args.id}.json"
        write_private(worker_path, worker)
        config["workers"][args.id] = token
        temp = directory / (".coordinator-" + secrets.token_hex(8) + ".json")
        try:
            write_private(temp, config)
            os.replace(temp, path)
        except BaseException:
            worker_path.unlink()
            if temp.exists():
                temp.unlink()
            raise
        print(f"Created {worker_path}. Transfer it privately to that worker only.")
        print("Restart the coordinator to load the new worker credential.")
    else:
        config = load(args.config)
        path = "/v1/jobs"
        body = None
        method = "GET"
        if args.action == "submit":
            command = args.command
            if command[:1] == ["--"]:
                command = command[1:]
            if not command:
                raise ValueError("Provide the executable and its arguments after --")
            body = {"image": args.image or config["allowed_images"][0],
                    "command": command, "timeout_seconds": args.timeout,
                    "cpus": args.cpus, "memory_mb": args.memory, "gpu": args.gpu}
            method = "POST"
        elif args.action == "status":
            if not re.fullmatch(r"[A-Za-z0-9_-]+", args.id):
                raise ValueError("Invalid job id")
            path += "/" + args.id
        from urllib.parse import urlsplit
        parsed = urlsplit(args.url)
        if (parsed.scheme not in ("http", "https") or not parsed.hostname
                or parsed.username is not None or parsed.password is not None
                or parsed.path not in ("", "/") or parsed.query or parsed.fragment):
            raise ValueError("Use an HTTP(S) origin without embedded credentials or a path")
        if parsed.scheme == "http" and parsed.hostname not in ("127.0.0.1", "localhost", "::1"):
            raise ValueError("Admin requests require HTTPS outside loopback; use an SSH tunnel for lab HTTP")
        result = request(args.url.rstrip("/") + path, config["admin_token"], method, body)
        print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, WorkerError, urllib.error.HTTPError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
