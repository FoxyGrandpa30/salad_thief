"""Small authenticated job coordinator for a trusted, private PCGrid network.

Run with ``python3 -m pcgrid.coordinator --config coordinator.json``. Put this
server behind HTTPS before connecting across an untrusted network.
"""

from __future__ import annotations

import argparse
import hmac
import json
import math
import os
import re
import secrets
import sqlite3
import sys
import time
from contextlib import contextmanager
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

MAX_BODY = 256 * 1024
MAX_OUTPUT = 64 * 1024
MAX_ATTEMPTS = 3
IMAGE_RE = re.compile(r"[a-z0-9][a-z0-9._:/-]*@sha256:[0-9a-f]{64}\Z")


class APIError(Exception):
    def __init__(self, status: int, message: str):
        self.status = status
        self.message = message


def utf8_size(value: str) -> int:
    try:
        return len(value.encode("utf-8"))
    except UnicodeError:
        raise APIError(400, "Strings must contain valid UTF-8 Unicode") from None


def valid_token(value: Any) -> bool:
    return isinstance(value, str) and 24 <= len(value) <= 1017 \
        and all(0x21 <= ord(char) <= 0x7e for char in value)


@dataclass(frozen=True)
class Config:
    database: Path
    admin_token: str
    workers: dict[str, str]
    allowed_images: tuple[str, ...]
    host: str = "127.0.0.1"
    port: int = 8080
    lease_seconds: float = 30

    @classmethod
    def load(cls, path: str | Path) -> "Config":
        config_path = Path(path).resolve()
        if os.name == "posix" and config_path.stat().st_mode & 0o077:
            raise ValueError("Coordinator configuration contains credentials: restrict it with chmod 600")
        with config_path.open("rb") as stream:
            raw = stream.read(MAX_BODY + 1)
        if len(raw) > MAX_BODY:
            raise ValueError("Coordinator configuration exceeds 256 KiB")
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError("Configuration must be a JSON object")
        admin = data.get("admin_token")
        workers = data.get("workers", {})
        images = data.get("allowed_images")
        if not valid_token(admin):
            raise ValueError("admin_token must contain 24-1017 visible ASCII characters without whitespace")
        if not isinstance(workers, dict) or any(
            not isinstance(k, str) or not k or len(k) > 128
            or not valid_token(v) for k, v in workers.items()
        ):
            raise ValueError("workers must map worker IDs to tokens of 24-1017 visible ASCII characters without whitespace")
        tokens = [admin, *workers.values()]
        if len(set(tokens)) != len(tokens):
            raise ValueError("Each administrator and worker requires a distinct token")
        if not isinstance(images, list) or not images or any(
            not isinstance(image, str) or len(image) > 512 or not IMAGE_RE.fullmatch(image) for image in images
        ):
            raise ValueError("allowed_images must be a nonempty list of digest-pinned images")
        database = data.get("database")
        if not isinstance(database, str) or not database:
            raise ValueError("database must be a file path")
        database_path = Path(database)
        if not database_path.is_absolute():
            database_path = config_path.parent / database_path
        host = data.get("host", "127.0.0.1")
        port = data.get("port", 8080)
        lease = data.get("lease_seconds", 30)
        if not isinstance(host, str) or not host:
            raise ValueError("host must be a nonempty string")
        if type(port) is not int or not 0 <= port <= 65535:
            raise ValueError("port must be an integer from 0 to 65535")
        if type(lease) not in (int, float) or not 1 <= lease <= 300 or not math.isfinite(lease):
            raise ValueError("lease_seconds must be between 1 and 300")
        return cls(database_path, admin, workers, tuple(images), host, port, lease)


class Store:
    def __init__(self, config: Config):
        self.config = config
        config.database.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.execute("PRAGMA journal_mode=WAL")
            db.execute("""CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY, spec TEXT NOT NULL,
                status TEXT NOT NULL, created_at REAL NOT NULL,
                updated_at REAL NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
                worker_id TEXT, lease_token TEXT, lease_until REAL,
                exit_code INTEGER, stdout TEXT NOT NULL DEFAULT '',
                stderr TEXT NOT NULL DEFAULT ''
            )""")
            db.execute("CREATE INDEX IF NOT EXISTS jobs_status_created ON jobs(status, created_at)")
        config.database.chmod(0o600)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.config.database, timeout=10, isolation_level=None)
        db.row_factory = sqlite3.Row
        try:
            with db:
                yield db
        finally:
            db.close()

    @staticmethod
    def expire(db: sqlite3.Connection, now: float) -> None:
        db.execute("""UPDATE jobs SET status='failed', updated_at=?,
            worker_id=NULL, lease_token=NULL, lease_until=NULL,
            stderr='Worker lease expired after maximum attempts'
            WHERE status='running' AND lease_until<=? AND attempts>=?""",
            (now, now, MAX_ATTEMPTS))
        db.execute("""UPDATE jobs SET status='queued', updated_at=?,
            worker_id=NULL, lease_token=NULL, lease_until=NULL
            WHERE status='running' AND lease_until<=?""", (now, now))

    @staticmethod
    def public(row: sqlite3.Row, summary: bool = False) -> dict[str, Any]:
        data = {
            **json.loads(row["spec"]),
            **{key: row[key] for key in (
                "id", "status", "created_at", "updated_at", "attempts",
                "worker_id", "exit_code", "stdout", "stderr",
            )},
        }
        if summary:
            for key in ("stdout", "stderr", "command"):
                data.pop(key, None)
        return data

    def submit(self, data: dict[str, Any]) -> dict[str, Any]:
        allowed = {"image", "command", "timeout_seconds", "cpus", "memory_mb", "gpu"}
        if set(data) - allowed:
            raise APIError(400, "Unsupported job fields")
        image = data.get("image")
        command = data.get("command")
        if not isinstance(image, str) or image not in self.config.allowed_images:
            raise APIError(400, "Image must be in the coordinator's digest-pinned allowlist")
        if not isinstance(command, list) or not 1 <= len(command) <= 64 or any(
            not isinstance(arg, str) or "\x00" in arg or utf8_size(arg) > 4096
            for arg in command
        ) or not command[0] or sum(utf8_size(arg) for arg in command) > 32768:
            raise APIError(400, "command must contain 1-64 arguments with a nonempty executable")
        timeout = data.get("timeout_seconds", 60)
        cpus = data.get("cpus", 1)
        memory = data.get("memory_mb", 512)
        gpu = data.get("gpu", False)
        if type(timeout) is not int or not 1 <= timeout <= 3600:
            raise APIError(400, "timeout_seconds must be an integer from 1 to 3600")
        if type(cpus) not in (int, float) or not 0.1 <= cpus <= 64 or not math.isfinite(cpus):
            raise APIError(400, "cpus must be a number from 0.1 to 64")
        if type(memory) is not int or not 32 <= memory <= 65536:
            raise APIError(400, "memory_mb must be an integer from 32 to 65536")
        if type(gpu) is not bool:
            raise APIError(400, "gpu must be a boolean")
        spec = dict(image=image, command=command, timeout_seconds=timeout,
                    cpus=cpus, memory_mb=memory, gpu=gpu)
        now = time.time()
        job_id = secrets.token_hex(16)
        with self.connect() as db:
            db.execute("INSERT INTO jobs(id,spec,status,created_at,updated_at) VALUES(?,?,'queued',?,?)",
                       (job_id, json.dumps(spec), now, now))
            return self.public(db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone())

    def list_jobs(self, job_id: str | None = None) -> dict[str, Any]:
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            self.expire(db, time.time())
            if job_id is not None:
                row = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
                if row is None:
                    raise APIError(404, "Job not found")
                return self.public(row)
            return {"jobs": [self.public(row, summary=True) for row in db.execute(
                "SELECT * FROM jobs ORDER BY created_at DESC LIMIT 1000") ]}

    def claim(self, worker: str, capabilities: dict[str, Any] | None = None) -> dict[str, Any] | None:
        caps = {"gpu": False, "max_cpus": 2, "max_memory_mb": 2048, "max_timeout_seconds": 3600}
        if capabilities is not None:
            if not isinstance(capabilities, dict) or set(capabilities) - set(caps):
                raise APIError(400, "Invalid worker capabilities")
            caps.update(capabilities)
        if type(caps["gpu"]) is not bool or type(caps["max_cpus"]) not in (int, float) \
                or not 0.1 <= caps["max_cpus"] <= 64 or not math.isfinite(caps["max_cpus"]) \
                or type(caps["max_memory_mb"]) is not int or not 32 <= caps["max_memory_mb"] <= 65536 \
                or type(caps["max_timeout_seconds"]) is not int or not 1 <= caps["max_timeout_seconds"] <= 3600:
            raise APIError(400, "Invalid worker capabilities")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            now = time.time()
            self.expire(db, now)
            if db.execute("SELECT 1 FROM jobs WHERE status='running' AND worker_id=?", (worker,)).fetchone():
                return None
            row = None
            for candidate in db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created_at"):
                spec = json.loads(candidate["spec"])
                if (not spec["gpu"] or caps["gpu"]) and spec["cpus"] <= caps["max_cpus"] \
                        and spec["memory_mb"] <= caps["max_memory_mb"] \
                        and spec["timeout_seconds"] <= caps["max_timeout_seconds"]:
                    row = candidate
                    break
            if row is None:
                return None
            token = secrets.token_urlsafe(32)
            db.execute("""UPDATE jobs SET status='running', worker_id=?, lease_token=?,
                lease_until=?, updated_at=?, attempts=attempts+1 WHERE id=?""",
                (worker, token, now + self.config.lease_seconds, now, row["id"]))
            return {"job": {**json.loads(row["spec"]), "id": row["id"],
                            "lease_token": token, "lease_seconds": self.config.lease_seconds}}

    def update(self, job_id: str, worker: str, data: dict[str, Any], result: bool) -> dict[str, Any]:
        lease = data.get("lease_token")
        if not isinstance(lease, str):
            raise APIError(400, "lease_token is required")
        if result:
            exit_code = data.get("exit_code")
            stdout, stderr = data.get("stdout", ""), data.get("stderr", "")
            if type(exit_code) is not int or not -255 <= exit_code <= 255:
                raise APIError(400, "exit_code must be an integer from -255 to 255")
            if any(not isinstance(text, str) or utf8_size(text) > MAX_OUTPUT for text in (stdout, stderr)):
                raise APIError(400, "stdout and stderr must each be at most 64 KiB")
        with self.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            now = time.time()
            row = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            if row is None:
                raise APIError(404, "Job not found")
            if row["status"] != "running" or row["worker_id"] != worker or row["lease_until"] <= now \
                    or not hmac.compare_digest(row["lease_token"], lease):
                raise APIError(409, "Lease is expired, completed, or belongs to another worker")
            if result:
                db.execute("""UPDATE jobs SET status=?, updated_at=?, exit_code=?,
                    stdout=?, stderr=?, lease_token=NULL, lease_until=NULL WHERE id=?""",
                    ("succeeded" if exit_code == 0 else "failed", now, exit_code, stdout, stderr, job_id))
                return {"id": job_id, "status": "succeeded" if exit_code == 0 else "failed"}
            db.execute("UPDATE jobs SET lease_until=?, updated_at=? WHERE id=?",
                       (now + self.config.lease_seconds, now, job_id))
            return {"id": job_id, "lease_seconds": self.config.lease_seconds}


class Coordinator(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, config: Config):
        self.config = config
        self.store = Store(config)
        super().__init__((config.host, config.port), Handler)

    def get_request(self):
        connection, address = super().get_request()
        connection.settimeout(15)
        return connection, address


class Handler(BaseHTTPRequestHandler):
    server: Coordinator

    def log_message(self, format: str, *args: Any) -> None:
        # Do not record request paths, arbitrary headers, or authentication material.
        pass

    def body(self) -> dict[str, Any]:
        if self.headers.get_all("Transfer-Encoding"):
            raise APIError(400, "Chunked request bodies are unsupported")
        lengths = self.headers.get_all("Content-Length", [])
        if len(lengths) != 1:
            raise APIError(400, "Exactly one Content-Length header is required")
        try:
            length = int(lengths[0])
        except ValueError:
            raise APIError(400, "Invalid Content-Length") from None
        if not 0 < length <= MAX_BODY:
            raise APIError(413 if length > MAX_BODY else 400, "Request body is empty or too large")
        raw = self.rfile.read(length)
        if len(raw) != length:
            raise APIError(400, "Request body is shorter than Content-Length")
        try:
            data = json.loads(raw)
        except (ValueError, UnicodeError, RecursionError):
            raise APIError(400, "Invalid JSON body") from None
        if not isinstance(data, dict):
            raise APIError(400, "Request body must be a JSON object")
        return data

    def authenticate(self, admin: bool) -> str:
        authorization = self.headers.get("Authorization", "")
        if not authorization.startswith("Bearer ") or len(authorization) > 1024:
            raise APIError(401, "Bearer authentication required")
        token = authorization[7:]
        if not token.isascii():
            raise APIError(401, "Invalid credentials")
        config = self.server.config
        if admin:
            if hmac.compare_digest(token, config.admin_token):
                return "admin"
        else:
            for worker_id, candidate in config.workers.items():
                if hmac.compare_digest(token, candidate):
                    return worker_id
        raise APIError(401, "Invalid credentials")

    def respond(self, status: int, data: Any = None) -> None:
        payload = b"" if data is None else json.dumps(data, ensure_ascii=True, allow_nan=False).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:
        self.dispatch("GET")

    def do_POST(self) -> None:
        self.dispatch("POST")

    def dispatch(self, method: str) -> None:
        self.connection.settimeout(15)
        try:
            path = urlsplit(self.path).path
            if method == "GET" and path == "/health":
                self.respond(200, {"status": "ok"})
                return
            if method == "POST" and path == "/v1/jobs/claim":
                worker = self.authenticate(False)
                data = self.body()
                if set(data) - {"capabilities"}:
                    raise APIError(400, "Unsupported claim fields")
                claim = self.server.store.claim(worker, data.get("capabilities"))
                self.respond(204 if claim is None else 200, claim)
                return
            match = re.fullmatch(r"/v1/jobs/([0-9a-f]{32})/(heartbeat|result)", path)
            if method == "POST" and match:
                worker = self.authenticate(False)
                data = self.body()
                self.respond(200, self.server.store.update(match[1], worker, data, match[2] == "result"))
                return
            if path == "/v1/jobs" and method in ("POST", "GET"):
                self.authenticate(True)
                if method == "POST":
                    self.respond(201, self.server.store.submit(self.body()))
                else:
                    self.respond(200, self.server.store.list_jobs())
                return
            match = re.fullmatch(r"/v1/jobs/([0-9a-f]{32})", path)
            if method == "GET" and match:
                self.authenticate(True)
                self.respond(200, self.server.store.list_jobs(match[1]))
                return
            raise APIError(404, "Endpoint not found")
        except APIError as error:
            self.respond(error.status, {"error": error.message})
        except (BrokenPipeError, ConnectionResetError, TimeoutError):
            self.close_connection = True
        except (sqlite3.Error, OSError, ValueError, TypeError, OverflowError):
            self.respond(500, {"error": "Internal coordinator error"})


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True, help="Path to secret-bearing coordinator JSON configuration")
    args = parser.parse_args(argv)
    try:
        config = Config.load(args.config)
        with Coordinator(config) as server:
            print(f"PCGrid coordinator listening on {config.host}:{server.server_port}", flush=True)
            server.serve_forever()
    except KeyboardInterrupt:
        return 0
    except (OSError, ValueError, sqlite3.Error) as error:
        print(f"Coordinator startup failed: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
