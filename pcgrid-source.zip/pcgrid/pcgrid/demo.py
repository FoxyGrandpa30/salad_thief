"""Prepare and queue a small, verifiable first job for a PCGrid worker."""

import argparse
import contextlib
import io
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import sys
import tempfile
import threading
import time
import unicodedata
from urllib.parse import urlsplit

from pcgrid import manage
from pcgrid.coordinator import APIError, Config, Coordinator
from pcgrid.worker import WorkerError, validate_config


# Official Python image: Python/ctypes are the only workload dependencies.
# Resolved and pulled during development; never substitute a mutable tag here.
DEMO_IMAGE = "docker.io/library/python@sha256:2d44738ebf4ce5f63b9d9ea871e9c7cfdc0426f7b0c97cac915fd88ded1d86bb"
DEFAULT_DIRECTORY = ".local/startup-demo"
JOB_SOURCE = Path(__file__).resolve().parents[1] / "examples" / "startup_job" / "job.py"
LOADER = ('import sys;exec(compile("".join(sys.argv[2:]),"pcgrid-startup-job.py","exec"),'
          '{"__name__":"__main__","DEMO_MODE":sys.argv[1]})')


def source_chunks(source, limit=3500):
    """Keep the reviewable source within the protocol's per-argument byte limit."""
    chunks, current, size = [], [], 0
    for char in source:
        width = len(char.encode("utf-8"))
        if size + width > limit:
            chunks.append("".join(current))
            current, size = [], 0
        current.append(char)
        size += width
    if current:
        chunks.append("".join(current))
    return chunks


def job_spec(mode="cpu"):
    if mode not in ("cpu", "gpu"):
        raise ValueError("Demo mode must be cpu or gpu")
    source = JOB_SOURCE.read_text(encoding="utf-8")
    command = ["/usr/local/bin/python3", "-c", LOADER, mode, *source_chunks(source)]
    if len(command) > 64 or sum(len(arg.encode("utf-8")) for arg in command) > 32768:
        raise ValueError("Demo source exceeds the worker's command-size budget")
    return {"image": DEMO_IMAGE, "command": command, "timeout_seconds": 180,
            "cpus": 1, "memory_mb": 1024 if mode == "gpu" else 256, "gpu": mode == "gpu"}


def prepare(directory, *, host="127.0.0.1", port=8080,
            worker_url=None, worker_id="startup-worker",
            gpu=False, allow_insecure_http=False, profile="standard"):
    """Create a new private setup atomically, without changing existing setups."""
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", worker_id):
        raise ValueError("Invalid worker id")
    if type(port) is not int or not 1 <= port <= 65535 or not host:
        raise ValueError("Use a nonempty host and a port from 1 to 65535")
    if profile not in ("standard", "laptop-cpu", "laptop-nvidia") or (profile == "laptop-cpu" and gpu):
        raise ValueError("Use standard, laptop-nvidia, or CPU-only laptop-cpu without --gpu")
    if worker_url is None:
        worker_url = f"http://127.0.0.1:{port}"
    validate_config({"coordinator_url": worker_url, "worker_token": "validation-only-" + "x" * 32,
                     "allowed_images": [DEMO_IMAGE], "gpu_enabled": gpu or profile == "laptop-nvidia",
                     "allow_insecure_http": allow_insecure_http})
    target = Path(directory).resolve()
    if target.exists():
        raise ValueError("Demo directory already exists; reuse it with start, or choose a new directory")
    target.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix=".pcgrid-demo-", dir=target.parent))
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            manage.main(["init", "--directory", str(stage), "--host", host,
                         "--port", str(port), "--image", DEMO_IMAGE])
            args = ["add-worker", "--directory", str(stage), "--id", worker_id, "--url", worker_url]
            args += ["--profile", profile]
            if gpu:
                args.append("--gpu")
            if allow_insecure_http:
                args.append("--allow-insecure-http")
            manage.main(args)
        config_path = stage / "coordinator.json"
        config = manage.load(config_path)
        config["database"] = str(target / "jobs.sqlite3")
        config_path.write_text(json.dumps(config, indent=2) + "\n")
        if target.exists():
            raise ValueError("Demo directory was created by another process; choose a new directory")
        os.rename(stage, target)
    finally:
        if stage.exists():
            shutil.rmtree(stage)
    return target / "coordinator.json", target / (worker_id + ".json")


def admin_origin(url):
    parsed = urlsplit(url)
    if (parsed.scheme not in ("http", "https") or not parsed.hostname
            or parsed.username is not None or parsed.password is not None
            or parsed.path not in ("", "/") or parsed.query or parsed.fragment):
        raise ValueError("Use an HTTP(S) origin without credentials or a path")
    _ = parsed.port
    if parsed.scheme == "http" and parsed.hostname not in ("127.0.0.1", "localhost", "::1"):
        raise ValueError("Admin requests require HTTPS outside loopback; administer a lab HTTP server locally")
    return url.rstrip("/")


def ensure_image(config):
    images = config.allowed_images if isinstance(config, Config) else config.get("allowed_images", [])
    if DEMO_IMAGE not in images:
        raise ValueError("The demo's pinned Python image must be approved in BOTH coordinator and worker configs; "
                         "use demo prepare for a new setup, then import the new worker file")


def safe_output(text):
    """Keep worker-controlled control sequences out of the operator's terminal."""
    return "".join(ascii(char)[1:-1] if unicodedata.category(char).startswith("C")
                   and char not in ("\n", "\t") else char for char in text)


def start(config_path, mode="cpu", exit_after_job=False):
    config = Config.load(config_path)
    ensure_image(config)
    with Coordinator(config) as server:
        job = server.store.submit(job_spec(mode))
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            print(f"Coordinator listening on {config.host}:{server.server_port}", flush=True)
            print(f"Demo job {job['id']} queued ({mode}). Boot the worker and import its configuration.", flush=True)
            previous = None
            while True:
                result = server.store.list_jobs(job["id"])
                status = result["status"]
                if status != previous:
                    print(f"Job {job['id']}: {status}", flush=True)
                    previous = status
                if status in ("succeeded", "failed"):
                    for stream in ("stdout", "stderr"):
                        if result[stream]:
                            print(safe_output(result[stream].rstrip()), flush=True)
                    if exit_after_job:
                        return 0 if status == "succeeded" else 1
                    print("Demo finished. Coordinator remains available for more jobs; Ctrl+C stops it.", flush=True)
                    while True:
                        time.sleep(1)
                time.sleep(0.25)
        except KeyboardInterrupt:
            return 0
        finally:
            server.shutdown()
            thread.join(timeout=5)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    setup = sub.add_parser("prepare", help="create new coordinator/worker credentials for this demo")
    setup.add_argument("--directory", default=DEFAULT_DIRECTORY)
    setup.add_argument("--host", default="127.0.0.1")
    setup.add_argument("--port", type=int, default=8080)
    setup.add_argument("--worker-url", help="worker's coordinator origin; defaults to loopback at --port")
    setup.add_argument("--worker-id", default="startup-worker")
    setup.add_argument("--gpu", action="store_true", help="enable GPU jobs in the generated worker configuration")
    setup.add_argument("--profile", choices=("standard", "laptop-cpu", "laptop-nvidia"), default="standard")
    setup.add_argument("--allow-insecure-http", action="store_true", help="explicit plaintext HTTP opt-in for a trusted LAN")
    for name in ("start", "queue"):
        command = sub.add_parser(name)
        command.add_argument("--config", default=DEFAULT_DIRECTORY + "/coordinator.json")
        command.add_argument("--mode", choices=("cpu", "gpu"), default="cpu")
        if name == "start":
            command.add_argument("--exit-after-job", action="store_true", help="stop this coordinator after the demo result")
        else:
            command.add_argument("--url", help="admin origin; defaults to loopback at the config's port")
    args = parser.parse_args(argv)
    if args.action == "prepare":
        coordinator, worker = prepare(args.directory, host=args.host, port=args.port,
                                      worker_url=args.worker_url, worker_id=args.worker_id,
                                      gpu=args.gpu, allow_insecure_http=args.allow_insecure_http,
                                      profile=args.profile)
        print(f"Coordinator config: {coordinator}")
        print(f"Worker config: {worker}")
        print("Copy only the worker file to the configuration USB as worker.json, or use it with the source worker.")
        if args.profile != "standard":
            backend = "NVIDIA CUDA" if args.profile == "laptop-nvidia" else "CPU only"
            print(f"Laptop profile: {backend}, 1 CPU quota, 1 GiB job RAM, AC power required. Use the updated laptop-capable USB image.")
        print("Credentials were not printed.")
        print(f"Start and queue the first job: python3 -m pcgrid.demo start --config {shlex.quote(str(coordinator))}")
        return 0
    if args.action == "start":
        return start(args.config, args.mode, args.exit_after_job)
    config = manage.load(args.config)
    ensure_image(config)
    url = args.url or f"http://127.0.0.1:{config.get('port', 8080)}"
    result = manage.request(admin_origin(url) + "/v1/jobs", config["admin_token"], "POST", job_spec(args.mode))
    print(f"Queued {args.mode} demo job: {result['id']}")
    print("The job waits in the queue until a compatible worker connects.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, WorkerError, APIError) as error:
        print(f"Demo error: {error}", file=sys.stderr)
        sys.exit(1)
