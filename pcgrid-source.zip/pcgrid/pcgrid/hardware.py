"""Read-only Linux hardware diagnostics; detection does not certify GPU execution."""

import argparse
import csv
import io
import json
import os
from pathlib import Path
import platform
import subprocess


LAPTOP_PROFILE = {"gpu_enabled": False, "require_ac_power": True,
                  "max_cpus": 1, "max_memory_mb": 1024, "max_timeout_seconds": 300}
WORKER_PROFILES = {"laptop-cpu": LAPTOP_PROFILE,
                   "laptop-nvidia": {**LAPTOP_PROFILE, "gpu_enabled": True}}
VENDORS = {"0x8086": "Intel", "0x1002": "AMD", "0x10de": "NVIDIA",
           "0x1234": "QEMU", "0x1b36": "QEMU"}
EXTERNAL_POWER_TYPES = {"Mains", "USB", "USB_C", "USB_PD", "USB_PD_DRP", "Wireless"}


def read_text(path):
    try:
        return Path(path).read_text().strip()
    except (OSError, UnicodeError):
        return None


def read_ac_power(root=Path("/sys/class/power_supply")):
    """True for online external power, False for known offline, None if unknown."""
    try:
        devices = list(Path(root).iterdir())
    except OSError:
        return None
    known_offline = False
    for device in devices:
        if read_text(device / "type") in EXTERNAL_POWER_TYPES:
            online = read_text(device / "online")
            if online == "1":
                return True
            if online == "0":
                known_offline = True
    return False if known_offline else None


def display_adapters(root=Path("/sys/bus/pci/devices")):
    try:
        devices = sorted(Path(root).iterdir())
    except OSError:
        return []
    adapters = []
    for device in devices:
        device_class = read_text(device / "class") or ""
        if not device_class.startswith("0x03"):
            continue
        vendor = read_text(device / "vendor") or "unknown"
        product = read_text(device / "device") or "unknown"
        adapters.append({"pci_address": device.name, "vendor": VENDORS.get(vendor, "Unknown"),
                         "device_id": vendor.removeprefix("0x") + ":" + product.removeprefix("0x")})
    return adapters


def nvidia_driver_devices():
    # Do not request serials, UUIDs, addresses, process lists or user data.
    try:
        result = subprocess.run(["nvidia-smi", "--query-gpu=name,driver_version,memory.total",
                                 "--format=csv,noheader,nounits"], capture_output=True,
                                text=True, timeout=5, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return []
    if result.returncode or len(result.stdout.encode()) > 65536:
        return []
    devices = []
    for row in csv.reader(io.StringIO(result.stdout)):
        if len(row) != 3:
            continue
        try:
            memory = int(row[2].strip())
        except ValueError:
            memory = None
        devices.append({"name": row[0].strip()[:160], "driver": row[1].strip()[:64],
                        "dedicated_memory_mb": memory})
    return devices


def report():
    memory = None
    meminfo = read_text("/proc/meminfo") or ""
    for line in meminfo.splitlines():
        if line.startswith("MemTotal:"):
            try:
                memory = int(line.split()[1]) // 1024
            except (ValueError, IndexError):
                pass
    nvidia = nvidia_driver_devices()
    return {"architecture": platform.machine(), "logical_cpus": os.cpu_count(),
            "system_memory_mb": memory, "ac_power_online": read_ac_power(),
            "display_adapters": display_adapters(), "nvidia_driver_devices": nvidia,
            "implemented_compute_backends": ["cpu", "nvidia-cuda"],
            "driver_detected_backends": ["cpu"] + (["nvidia-cuda"] if nvidia else []),
            "intel_amd_acceleration": "Not implemented; detected adapters can use CPU jobs",
            "gpu_readiness": "Requires an actual container/CUDA test; discovery alone is insufficient",
            "laptop_profiles": WORKER_PROFILES}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.parse_args(argv)
    print(json.dumps(report(), indent=2, ensure_ascii=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
