# PCGrid live USB prototype

This custom Debian 13 (trixie) live system is intended for a **private network of
trusted PC owners and approved workloads**. It is not a public Salad replacement.
The image supports private CPU jobs on x86-64 and includes the NVIDIA CUDA
backend for compatible cards, including the RTX 3050 Laptop test target.
Intel/AMD display firmware and adapter discovery are included; their GPU
compute backends have not been implemented. See the
[hardware profiles](../docs/HARDWARE_SUPPORT.md).
Driver compatibility must still be checked on each actual GPU before claiming
support. There is no GPU attached to the development cloud environment.

The image boots without installing an OS. It uses a RAM overlay, disables disk
swap and persistence, has no installer or SSH server, and searches removable
media for its live filesystem (`live-media=removable`). It does not mount or
format internal disks. Shut down before removing the boot USB, then reboot into
the PC's normal operating system. The prototype does not support USB SSDs that report
`removable=0`; this restriction prevents falling back to scanning internal disks.

## Build

Use an x86-64 disposable Linux build VM with Docker Engine, at least 8 GB RAM,
and approximately 20 GB free storage. Building the NVIDIA kernel modules can take
time. The Debian container base is pinned by digest; NVIDIA driver packages are
pinned to `595.112.07-1` and NVIDIA Container Toolkit to `1.20.1-1`. Debian security
updates are resolved during the initial/full OS build. Application-only rebuilds
reuse the cached OS, kernel, and driver; they do not refresh security updates.
Repeated builds need not be byte-identical.
The resulting package manifest records the installed versions. Build state is
retained in the Docker volume `pcgrid-live-build-work` to aid troubleshooting;
it is build cache, not worker enrollment or runtime data.

From the repository root:

```sh
./image/build.sh --allow-privileged-build ./dist
```

`live-build` requires chroot and mount capabilities. The script explicitly uses a
privileged build container, freezes the worker/image inputs into a read-only
snapshot, and writes output only to
the selected output directory. Never run an unknown privileged builder on a
machine containing valuable data. No physical disk is flashed by this command.
An early mount-capability check prevents a long doomed build on restricted hosts.
Normal TLS verification and apt signature verification remain enabled. On a
network with an intercepting TLS proxy, the builder can use the public trust
anchor at `PCGRID_BUILD_CA_FILE` (or the cloud-provided `CODEX_PROXY_CERT` path).
The build-only trust anchor is removed from the live OS and its regenerated
initramfs before packaging; certificate verification is never disabled.

Outputs on successful completion:

- `dist/pcgrid-live-amd64.iso`
- `dist/pcgrid-live-amd64.iso.sha256`
- `dist/pcgrid-live-amd64.packages`
- `dist/build.log`

Verify before flashing:

```sh
cd dist
sha256sum --check pcgrid-live-amd64.iso.sha256
```

Use an image-writing tool such as Rufus in DD mode or balenaEtcher to write the
ISO to a **spare USB drive**. This overwrites that USB drive; verify the target
carefully. The build script never chooses or writes a physical drive for you.

## Rebuilds and security refreshes

The saved build command detects changes to base packages, OS options, driver
installation and build tools. Those changes rebuild the OS. Worker and overlay
changes refresh runtime files while reusing the compiled OS, then regenerate
squashfs and the ISO. Each run freezes inputs before starting, so
editing source during a build affects the following build, not the running one.

For a **full OS/security refresh**, finish or stop all builds on the disposable
build VM, then delete only this project's generated Docker build-cache volume:

```sh
docker volume rm pcgrid-live-build-work
./image/build.sh --allow-privileged-build ./dist
```

This removes cached build state, not repository files or already exported ISOs.
The next build downloads current signed Debian packages and recompiles the
pinned NVIDIA driver. Driver/toolkit pins themselves require an explicit source
change and revalidation when updating those components. Running USB systems do
not update automatically; write and test a newly built image on a spare USB.

## First boot and enrollment

1. Start the coordinator on another machine using the root README instructions.
   Use HTTPS for remote operation; the standard-library coordinator itself needs
   a properly configured TLS reverse proxy for HTTPS.
2. Generate a different worker configuration for each PC with `pcgrid.manage`.
   Never include the admin token or the same worker token in a distributable ISO.
3. On a separate removable configuration USB, create a FAT or ext4 filesystem
   labelled `PCGRID_CFG`. Copy that PC's generated configuration to its root as
   `worker.json`. Keep this USB private: the file contains that worker's token.
4. Boot the live USB using the PC's one-time boot menu. For this prototype,
   disable Secure Boot in firmware; the custom DKMS module is not signed by a
   key enrolled on the PC. This is unrelated to download/signature verification. Before changing firmware
   settings on a BitLocker-protected Windows PC, have its recovery key available;
   Secure Boot changes can trigger a recovery prompt.
5. Connect Ethernet, or use **Configure network** in the physical console for Wi-Fi.
6. Choose **Import this PC's worker configuration**. Only a configuration USB
   marked removable is accepted; it is mounted read-only. The file is validated
   and copied with root-only permissions into the RAM overlay.
7. Use **Show GPU and worker status**. Confirm that `nvidia-smi` identifies the
   expected GPU, then execute a pinned CUDA workload submitted by the coordinator.

CPU-only configs are now accepted. For the HP laptop, use
`pcgrid.demo prepare --profile laptop-nvidia` as in the hardware guide; use
`laptop-cpu` on an unverified/non-NVIDIA laptop. Both require external AC power.
The new **hardware, power and storage diagnostics** console option shows the
detected adapters and AC state. Earlier ISOs do not enforce this AC policy;
write the newly built ISO before testing it.

Use **Pause jobs** before removing the PC from the network. The worker service
has no listening network port. The physical console controls networking, job
execution, logs, and shutdown; there is no shared login password.

At boot, a self-test verifies that D-Bus and NetworkManager are running and
responding; this does not require Internet access or certify Wi-Fi hardware.
Its network-service marker is `PCGRID_NETWORK_SERVICES_OK`.
The offline container test executes a signed-Debian BusyBox binary through the
same Docker runtime and container restrictions as jobs. It verifies a nonroot
process can execute and write its temporary directory. Its success marker is
`PCGRID_DOCKER_SELFTEST_OK`. A failed self-test blocks the worker; the physical
console remains available. The console can rerun it. This tests CPU container
execution, not NVIDIA/CUDA computation.

Docker's data directory has its own RAM-backed tmpfs mount and uses overlay2,
avoiding an unsupported nested overlay on the live root filesystem. Its maximum
size is half the PC's RAM. Allow sufficient RAM for the OS, cached container
layers, models, and active jobs; large AI images can need 32 GB or more total RAM.
No amount of GPU VRAM substitutes for space in this RAM-backed image cache.

On reboot, configuration, Wi-Fi credentials, cached container images, and local
logs disappear. Reimport the unique configuration USB. Job results already sent
to the coordinator remain there. Persisting data on internal drives is outside
this prototype's scope. Container image downloads consume RAM-backed storage;
large AI images/models require sufficient RAM and are not bundled in this ISO.

## GPU and security boundaries

The headless NVIDIA stack includes open kernel modules, CUDA driver libraries,
`nvidia-smi`, and NVIDIA Container Toolkit configured for Docker. It targets
Turing-and-newer hardware; it is not an image for older NVIDIA, AMD, or Apple GPUs.
The selected driver is new enough for RTX 5090, but no claim of physical GPU
validation is made until it has been booted and tested on each GPU model.

A job receives GPU access only when both the worker and job enable it. Containers
share the host kernel and GPU driver, so this is not a sufficient boundary for
hostile public workloads. GPU access exposes additional driver attack surface.
Use trusted participants and approved digest-pinned images. No host folders or
Docker socket are passed into job containers. GPU memory is not hard-partitioned
between jobs; the prototype runs one job per worker.

There are no marketplace payments, customer-data confidentiality guarantees,
automatic updates, GUI, public enrollment, or availability commitments. NVIDIA
user-space components and firmware carry their own distribution terms; retain
those license notices and review the applicable terms before redistribution.

## Required hardware acceptance checks

A successfully generated ISO is not proof of a working physical boot. Before
distributing it beyond a lab, check all of the following on the intended PCs:

- UEFI and, if needed, legacy BIOS boot; Secure Boot is currently unsupported.
- Internal filesystems and swap remain unmounted/inactive (`findmnt`, `swapon`).
- Ethernet/Wi-Fi works without persisting secrets on an internal disk.
- `nvidia-smi` succeeds on an RTX 3060, RTX 4090, and RTX 5090.
- A digest-pinned CUDA container sees the GPU and finishes a real computation.
- Pausing/stopping the worker removes its running job container.
- A disconnected worker's job is recovered by the coordinator without duplicate
  completion or accounting.
- A clean reboot requires configuration reimport and leaves the installed OS
  unchanged.
