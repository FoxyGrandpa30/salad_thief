#!/bin/bash
set -euo pipefail
ROOT=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)
if [[ ${1:-} != --allow-privileged-build ]]; then
    cat >&2 <<'HELP'
Usage: ./image/build.sh --allow-privileged-build [OUTPUT_DIRECTORY]

Builds a Debian live USB ISO in an isolated Docker builder. live-build needs
mount/chroot capabilities, so the builder runs privileged. Only use this on a
trusted, disposable Linux build machine. Nothing is written to a physical disk.
The repository is mounted read-only. Output includes a potentially multi-GB ISO.
HELP
    exit 2
fi
OUT=${2:-"$ROOT/dist"}
mkdir -p -- "$OUT"
OUT=$(cd -- "$OUT" && pwd)
if [[ $OUT == / || $OUT == "$ROOT" ]]; then
    echo 'Choose a dedicated output directory.' >&2
    exit 2
fi
command -v docker >/dev/null
if ! docker info >/dev/null 2>&1; then
    echo 'A running Docker Engine is required.' >&2
    exit 1
fi
# Docker build does not always inherit proxy DNS or environment from docker run.
# Pass proxy variables by name, never interpolate credentials into scripts/logs.
BUILD_ARGS=(--build-arg HTTP_PROXY --build-arg HTTPS_PROXY --build-arg NO_PROXY
            --build-arg http_proxy --build-arg https_proxy --build-arg no_proxy)
if command -v python3 >/dev/null; then
    PCGRID_PROXY_HOST=$(python3 - <<'PYPROXY'
import os, urllib.parse
print(urllib.parse.urlsplit(os.environ.get('https_proxy') or os.environ.get('HTTPS_PROXY') or '').hostname or '')
PYPROXY
)
    if [[ -n $PCGRID_PROXY_HOST ]] && command -v getent >/dev/null; then
        PCGRID_PROXY_IP=$(getent ahostsv4 "$PCGRID_PROXY_HOST" | awk 'NR == 1 {print $1}' || true)
        if [[ -n $PCGRID_PROXY_IP ]]; then
            BUILD_ARGS+=(--add-host "$PCGRID_PROXY_HOST:$PCGRID_PROXY_IP")
        fi
    fi
fi
# Keep Docker's transient build configuration outside read-only home directories.
PCGRID_DOCKER_TMP=$(mktemp -d)
trap 'rm -rf -- "$PCGRID_DOCKER_TMP"' EXIT
# Freeze build inputs before starting. A later source edit must affect the next
# build, never the shell script currently being interpreted in a container.
PCGRID_SOURCE_SNAPSHOT="$PCGRID_DOCKER_TMP/source"
mkdir -p "$PCGRID_SOURCE_SNAPSHOT/pcgrid"
cp -a "$ROOT/image" "$PCGRID_SOURCE_SNAPSHOT/image"
mkdir -p "$PCGRID_SOURCE_SNAPSHOT/image/overlay/opt/pcgrid"
cp "$ROOT/LICENSE" "$PCGRID_SOURCE_SNAPSHOT/image/overlay/opt/pcgrid/LICENSE"
cp "$ROOT/pcgrid/__init__.py" "$ROOT/pcgrid/worker.py" "$ROOT/pcgrid/hardware.py" "$PCGRID_SOURCE_SNAPSHOT/pcgrid/"
DOCKER_CONFIG="$PCGRID_DOCKER_TMP" docker build "${BUILD_ARGS[@]}" \
    --tag pcgrid-live-builder --file "$PCGRID_SOURCE_SNAPSHOT/image/Dockerfile" "$PCGRID_SOURCE_SNAPSHOT/image"
RUN_ARGS=(--rm --privileged
    --mount "type=bind,src=$PCGRID_SOURCE_SNAPSHOT,dst=/source,readonly"
    --mount "type=bind,src=$OUT,dst=/output"
    --mount "type=volume,src=pcgrid-live-build-work,dst=/work")
PCGRID_BUILD_CA_FILE=${PCGRID_BUILD_CA_FILE:-${CODEX_PROXY_CERT:-}}
if [[ -n $PCGRID_BUILD_CA_FILE ]]; then
    [[ -f $PCGRID_BUILD_CA_FILE ]] || { echo 'Build CA file does not exist.' >&2; exit 1; }
    RUN_ARGS+=(--mount "type=bind,src=$PCGRID_BUILD_CA_FILE,dst=/run/pcgrid-build-proxy.crt,readonly")
fi
docker run "${RUN_ARGS[@]}" --entrypoint /bin/bash pcgrid-live-builder /source/image/build-inside.sh
printf 'Image and checksums saved in %s\n' "$OUT"
