#!/bin/bash
# Base OS options; changes invalidate the compiled OS cache.
lb config \
    --mode debian --distribution trixie --architectures amd64 \
    --build-with-chroot false \
    --debootstrap-options "--include=ca-certificates" \
    --binary-images iso-hybrid --debian-installer none \
    --archive-areas 'main contrib non-free non-free-firmware' \
    --mirror-bootstrap https://deb.debian.org/debian \
    --mirror-chroot https://deb.debian.org/debian \
    --mirror-binary https://deb.debian.org/debian \
    --mirror-chroot-security https://security.debian.org/debian-security \
    --mirror-binary-security https://security.debian.org/debian-security \
    --apt-recommends false --firmware-chroot false --firmware-binary false \
    --memtest none \
    --bootappend-live 'boot=live components console=tty0 console=ttyS0,115200 hostname=pcgrid-node live-media=removable systemd.gpt_auto=no rd.systemd.gpt_auto=no noresume noswap nopersistence noeject live-config.noroot live-config.noautologin' \
    --bootappend-live-failsafe 'boot=live components console=tty0 console=ttyS0,115200 hostname=pcgrid-node live-media=removable systemd.gpt_auto=no rd.systemd.gpt_auto=no noresume noswap nopersistence noeject live-config.noroot live-config.noautologin nomodeset' \
    --iso-application 'PCGrid trusted GPU worker prototype' \
    --iso-volume 'PCGRID_LIVE'
