#!/bin/bash
set -euo pipefail
umask 022
[[ $(id -u) == 0 ]] || { echo 'Build container must run as root.' >&2; exit 1; }
[[ -f /source/pcgrid/worker.py ]] || { echo 'Missing worker source.' >&2; exit 1; }
[[ -d /output && -w /output ]] || { echo 'Writable /output required.' >&2; exit 1; }
# Stop before downloading gigabytes if this host cannot support live-build.
mkdir -p /work/mount-check
if ! mount -t tmpfs tmpfs /work/mount-check; then
    echo 'This build host does not permit mounts. Use a disposable Linux VM with privileged Docker support.' >&2
    exit 1
fi
umount /work/mount-check
rmdir /work/mount-check
if [[ -f /run/pcgrid-build-proxy.crt ]]; then
    openssl x509 -in /run/pcgrid-build-proxy.crt -noout
    install -m 0644 /run/pcgrid-build-proxy.crt /usr/local/share/ca-certificates/pcgrid-build-proxy.crt
    update-ca-certificates
fi
mkdir -p /work/live
cd /work/live
. /source/image/os-config.sh

printf 'MKSQUASHFS_OPTIONS="-processors 4"\n' >> config/common
mkdir -p config/package-lists config/includes.chroot config/hooks/live config/apt
install_runtime_overlay() {
    # Workspace umasks/ownership must never turn /, /etc or /usr into private
    # directories when copying the overlay. It contains public OS files only.
    tar --create --file=- --directory=/source/image/overlay \
        --owner=0 --group=0 --mode='u=rwX,go=rX' . | \
        tar --extract --file=- --directory="$1"
    install -d -m 0755 -o 0 -g 0 "$1/opt/pcgrid/pcgrid"
    install -m 0644 -o 0 -g 0 /source/pcgrid/__init__.py \
        /source/pcgrid/worker.py /source/pcgrid/hardware.py "$1/opt/pcgrid/pcgrid/"
}
cat > config/apt/apt.conf <<'APTCONF'
APT::Update::Error-Mode "any";
Acquire::Retries "1";
Acquire::https::Timeout "30";
APTCONF
# live-build's Chroot helper passes http_proxy but drops https_proxy by default.
PCGRID_HTTPS_PROXY=${https_proxy:-${HTTPS_PROXY:-${http_proxy:-}}}
if [[ -n $PCGRID_HTTPS_PROXY ]]; then
    printf 'https_proxy=%s\n' "$PCGRID_HTTPS_PROXY" > config/environment.chroot
    printf 'Acquire::https::Proxy "%s";\n' "$PCGRID_HTTPS_PROXY" >> config/apt/apt.conf
else
    rm -f config/environment.chroot
fi
mkdir -p config/bootloaders/isolinux config/bootloaders/grub-pc
sed 's/^timeout 0$/timeout 100/' /usr/share/live/build/bootloaders/isolinux/isolinux.cfg > config/bootloaders/isolinux/isolinux.cfg
{ printf 'set timeout=10\n'; cat /usr/share/live/build/bootloaders/grub-pc/config.cfg; } > config/bootloaders/grub-pc/config.cfg
install_runtime_overlay config/includes.chroot
cp /source/image/os-packages.list config/package-lists/pcgrid.list.chroot
cp /source/image/hooks/* config/hooks/live/
chmod +x config/hooks/live/*
# live-build propagates failure status. Its log is retained for diagnosis.
# Only base-package/driver changes require rebuilding the compiled OS. Runtime
# code and overlays are refreshed on every build before resealing the ISO.
PCGRID_OS_KEY=$({
    sha256sum /source/image/os-config.sh /source/image/os-packages.list \
        /source/image/hooks/0100-nvidia.hook.chroot /source/image/Dockerfile
} | sha256sum | cut -d ' ' -f 1)
set +e
(
    set -e
    if [[ -d chroot && -f .build/chroot_hacks && -f .pcgrid-os-key ]] && \
       [[ $(cat .pcgrid-os-key) == "$PCGRID_OS_KEY" ]]; then
        echo 'Reusing completed OS/kernel/driver; rebuilding application filesystem and ISO.'
        lb clean --binary
        rm -rf cache/binary_rootfs
    else
        # A killed build cannot retain mount namespaces/stage locks. Restore
        # the verified bootstrap cache rather than trust a partial chroot.
        if [[ -d chroot ]]; then
            lb clean --chroot --binary
            rm -f .build/bootstrap*
        fi
        lb bootstrap
        if [[ -f /run/pcgrid-build-proxy.crt ]]; then
            install -m 0644 /run/pcgrid-build-proxy.crt chroot/usr/local/share/ca-certificates/pcgrid-build-proxy.crt
            chroot chroot update-ca-certificates
        fi
        lb chroot
        if [[ -f chroot/usr/local/share/ca-certificates/pcgrid-build-proxy.crt ]]; then
            rm chroot/usr/local/share/ca-certificates/pcgrid-build-proxy.crt
            chroot chroot update-ca-certificates --fresh
            lb chroot_prep install 'devpts proc selinuxfs sysfs'
            chroot chroot update-initramfs -u -k all
            lb chroot_prep remove 'devpts proc selinuxfs sysfs'
        fi
    fi
    # Refresh runtime-only inputs even when reusing verified OS packages.
    install_runtime_overlay chroot
    rm -rf chroot/opt/pcgrid/pcgrid/__pycache__
    chroot chroot /bin/sh < /source/image/hooks/0200-services.hook.chroot
    # The overlay supplies storage/logging settings; merge the NVIDIA runtime
    # using its supported configurator rather than lose it on an overlay copy.
    chroot chroot nvidia-ctk runtime configure --runtime=docker
    : > chroot/etc/machine-id
    rm -f chroot/var/lib/dbus/machine-id chroot/var/lib/systemd/random-seed
    chroot chroot /bin/sh < /source/image/hooks/0999-clean-build-trust.hook.chroot
    chroot chroot /bin/sh < /source/image/hooks/0980-binary-check.hook.chroot
    printf '%s\n' "$PCGRID_OS_KEY" > .pcgrid-os-key
    # Keep output inventories in sync with application refreshes and removed
    # build-only trust. These are generated metadata, not files in the live OS.
    chroot chroot dpkg-query -W > chroot.packages.live
    chroot chroot ls -lR > chroot.files
    lb installer
    lb binary
    lb source
) 2>&1 | tee /output/build.log
result=${PIPESTATUS[0]}
set -e
if [[ $result != 0 ]]; then
    exit "$result"
fi
install -m 0644 live-image-amd64.hybrid.iso /output/pcgrid-live-amd64.iso
cp live-image-amd64.packages /output/pcgrid-live-amd64.packages
cd /output
sha256sum pcgrid-live-amd64.iso > pcgrid-live-amd64.iso.sha256
