"""Small PCGrid demonstration: CPU simulation or real NVIDIA CUDA vector add.

Uses only Python's standard library. GPU mode loads the real CUDA driver and
does not fall back to CPU. Driver ABI signatures were checked against NVIDIA's
CUDA 12.8 cuda.h (nvidia-cuda-runtime-cu12==12.8.90, official PyPI wheel SHA256
adade8dcbd0edf427b7204d480d6066d33902cab2a4707dcfc48a2d0fd44ab90).
No SDK, compiler, benchmark, model, or network access is required in the job.
"""

import contextlib
import ctypes as ct
import json
import os
import sys
import time


NELEMENTS = 65536
ELEMENTS = NELEMENTS
CHECKSUM = NELEMENTS * 1023
ROUNDS = 5
PAUSE_SECONDS = 0.5

# Forward-compatible PTX, targeting Turing and newer NVIDIA GPUs. This performs
# an actual GPU kernel launch; merely finding a GPU is not a passing result.
PTX = r"""
.version 7.0
.target sm_75
.address_size 64
.visible .entry vector_add(
    .param .u64 input_a,
    .param .u64 input_b,
    .param .u64 output_c,
    .param .u32 length
)
{
    .reg .pred %p1;
    .reg .b32 %r<9>;
    .reg .b64 %rd<8>;
    ld.param.u64 %rd1, [input_a];
    ld.param.u64 %rd2, [input_b];
    ld.param.u64 %rd3, [output_c];
    ld.param.u32 %r5, [length];
    mov.u32 %r1, %ctaid.x;
    mov.u32 %r2, %ntid.x;
    mov.u32 %r3, %tid.x;
    mad.lo.s32 %r4, %r1, %r2, %r3;
    setp.ge.u32 %p1, %r4, %r5;
    @%p1 bra DONE;
    mul.wide.u32 %rd4, %r4, 4;
    add.s64 %rd5, %rd1, %rd4;
    add.s64 %rd6, %rd2, %rd4;
    add.s64 %rd7, %rd3, %rd4;
    ld.global.u32 %r6, [%rd5];
    ld.global.u32 %r7, [%rd6];
    add.s32 %r8, %r6, %r7;
    st.global.u32 [%rd7], %r8;
DONE:
    ret;
}
"""


class DemoError(Exception):
    pass


def emit(event, **fields):
    print(json.dumps({"event": event, **fields}, sort_keys=True), flush=True)


def inputs(elements):
    array_type = ct.c_int32 * elements
    left = array_type(*(index % 1024 for index in range(elements)))
    right = array_type(*((index * 7) % 1024 for index in range(elements)))
    return left, right


def verify(values, elements):
    if len(values) != elements:
        raise DemoError("Result length does not match the requested vector length")
    checksum = 0
    for index, value in enumerate(values):
        expected = index % 1024 + (index * 7) % 1024
        if value != expected:
            raise DemoError(f"Verification failed at element {index}: expected {expected}, got {value}")
        checksum += value
    # Each 1024-element period contains a permutation of 0..1023 in each input.
    # This independent closed-form sum also catches unexpected aggregate output.
    if checksum != elements * 1023:
        raise DemoError("Result checksum does not match the closed-form reference")
    return checksum


class CudaVector:
    """Small synchronous CUDA driver client; all calls remain on one thread."""

    def __init__(self, left, right, loader=None):
        self.left, self.right = left, right
        self.elements = len(left)
        self.context = ct.c_void_p()
        self.module = ct.c_void_p()
        self.kernel = ct.c_void_p()
        self.addresses = []
        self.name = ""
        # The live worker has a writable /tmp and a read-only root filesystem.
        # Disable disk JIT caching; this tiny module is compiled once per job.
        os.environ["CUDA_CACHE_DISABLE"] = "1"
        try:
            self.library = (loader or ct.CDLL)("libcuda.so.1")
        except OSError as exc:
            raise DemoError("CUDA driver library is unavailable. GPU mode requires an NVIDIA-enabled worker; no CPU fallback was used.") from exc
        pointer = ct.c_void_p
        device_pointer = ct.c_uint64  # CUdeviceptr_v2 on Linux x86-64.
        specifications = {
            "cuInit": [ct.c_uint],
            "cuDeviceGetCount": [ct.POINTER(ct.c_int)],
            "cuDeviceGet": [ct.POINTER(ct.c_int), ct.c_int],
            "cuDeviceGetName": [pointer, ct.c_int, ct.c_int],
            "cuCtxCreate_v2": [ct.POINTER(pointer), ct.c_uint, ct.c_int],
            "cuMemAlloc_v2": [ct.POINTER(device_pointer), ct.c_size_t],
            "cuMemcpyHtoD_v2": [device_pointer, pointer, ct.c_size_t],
            "cuMemcpyDtoH_v2": [pointer, device_pointer, ct.c_size_t],
            "cuMemFree_v2": [device_pointer],
            "cuModuleLoadData": [ct.POINTER(pointer), pointer],
            "cuModuleGetFunction": [ct.POINTER(pointer), pointer, ct.c_char_p],
            "cuLaunchKernel": [pointer, ct.c_uint, ct.c_uint, ct.c_uint,
                               ct.c_uint, ct.c_uint, ct.c_uint, ct.c_uint,
                               pointer, ct.POINTER(pointer), ct.POINTER(pointer)],
            "cuCtxSynchronize": [],
            "cuModuleUnload": [pointer],
            "cuCtxDestroy_v2": [pointer],
            "cuGetErrorName": [ct.c_int, ct.POINTER(ct.c_char_p)],
            "cuGetErrorString": [ct.c_int, ct.POINTER(ct.c_char_p)],
        }
        self.functions = {}
        for name, arguments in specifications.items():
            try:
                function = getattr(self.library, name)
            except AttributeError as exc:
                raise DemoError(f"CUDA driver is missing required API {name}") from exc
            function.argtypes = arguments
            function.restype = ct.c_int
            self.functions[name] = function

    def call(self, name, *arguments):
        code = self.functions[name](*arguments)
        if code:
            label, description = ct.c_char_p(), ct.c_char_p()
            self.functions["cuGetErrorName"](code, ct.byref(label))
            self.functions["cuGetErrorString"](code, ct.byref(description))
            error_name = (label.value or b"CUDA_ERROR").decode("utf-8", errors="replace")
            detail = (description.value or b"No driver description").decode("utf-8", errors="replace")
            raise DemoError(f"{name} failed: {error_name} ({code}): {detail[:240]}")

    def __enter__(self):
        try:
            self.call("cuInit", 0)
            count = ct.c_int()
            self.call("cuDeviceGetCount", ct.byref(count))
            if count.value < 1:
                raise DemoError("No CUDA GPU was detected; GPU mode did not fall back to CPU")
            device = ct.c_int()
            self.call("cuDeviceGet", ct.byref(device), 0)
            name = ct.create_string_buffer(256)
            self.call("cuDeviceGetName", name, len(name), device.value)
            self.name = name.value.decode("utf-8", errors="replace")[:120]
            # CU_CTX_SCHED_BLOCKING_SYNC avoids burning CPU while synchronizing.
            self.call("cuCtxCreate_v2", ct.byref(self.context), 4, device.value)
            self.ptx_buffer = ct.create_string_buffer(PTX.encode("ascii"))
            self.call("cuModuleLoadData", ct.byref(self.module), self.ptx_buffer)
            self.call("cuModuleGetFunction", ct.byref(self.kernel), self.module, b"vector_add")
            for _ in range(3):
                address = ct.c_uint64()
                self.call("cuMemAlloc_v2", ct.byref(address), ct.sizeof(self.left))
                self.addresses.append(address)
            self.call("cuMemcpyHtoD_v2", self.addresses[0], self.left, ct.sizeof(self.left))
            self.call("cuMemcpyHtoD_v2", self.addresses[1], self.right, ct.sizeof(self.right))
            return self
        except BaseException:
            self.close(suppress=True)
            raise

    def compute(self):
        length = ct.c_uint32(self.elements)
        parameters = (ct.c_void_p * 4)(
            *(ct.cast(ct.byref(value), ct.c_void_p) for value in [*self.addresses, length]))
        block_size = 256
        self.call("cuLaunchKernel", self.kernel,
                  (self.elements + block_size - 1) // block_size, 1, 1,
                  block_size, 1, 1, 0, None, parameters, None)
        self.call("cuCtxSynchronize")
        output = (ct.c_int32 * self.elements)()
        self.call("cuMemcpyDtoH_v2", output, self.addresses[2], ct.sizeof(output))
        return output

    def close(self, suppress=False):
        errors = []
        while self.addresses:
            address = self.addresses.pop()
            try:
                self.call("cuMemFree_v2", address)
            except DemoError as exc:
                errors.append(str(exc))
        for name, handle in (("cuModuleUnload", self.module), ("cuCtxDestroy_v2", self.context)):
            if handle.value:
                try:
                    self.call(name, handle)
                except DemoError as exc:
                    errors.append(str(exc))
                handle.value = None
        if errors and not suppress:
            raise DemoError("CUDA cleanup failed: " + "; ".join(errors)[:350])

    def __exit__(self, kind, value, traceback):
        self.close(suppress=kind is not None)


def main(mode="cpu", *, elements=ELEMENTS, rounds=ROUNDS, pause=PAUSE_SECONDS):
    started = time.monotonic()
    try:
        if mode not in ("cpu", "gpu"):
            raise DemoError("Demo mode must be cpu or gpu")
        if type(elements) is not int or not 1024 <= elements <= ELEMENTS or elements % 1024:
            raise DemoError("elements must be a multiple of 1024 from 1024 to 65536")
        if type(rounds) is not int or not 1 <= rounds <= ROUNDS:
            raise DemoError("rounds must be between 1 and 5")
        if type(pause) not in (int, float) or not 0 <= pause <= PAUSE_SECONDS:
            raise DemoError("pause must be between 0 and 0.5 seconds")
        left, right = inputs(elements)
        backend = CudaVector(left, right) if mode == "gpu" else contextlib.nullcontext()
        with backend as gpu:
            device = gpu.name if gpu is not None else "CPU simulation (does not validate a GPU)"
            emit("START", mode=mode, device=device, elements=elements, rounds=rounds,
                 gpu_array_bytes=ct.sizeof(left) * 3 if gpu is not None else 0)
            for index in range(rounds):
                values = gpu.compute() if gpu is not None else [a + b for a, b in zip(left, right)]
                checksum = verify(values, elements)
                emit("PROGRESS", mode=mode, round=index + 1, rounds=rounds,
                     checked_elements=elements, checksum=checksum)
                time.sleep(pause)
        emit("PASS", mode=mode, device=device, elements=elements, rounds=rounds,
             checksum=checksum, elapsed_seconds=round(time.monotonic() - started, 3),
             note="Functional demonstration, not a performance benchmark")
        return 0
    except (DemoError, OSError, ValueError) as exc:
        emit("FAIL", mode=mode if isinstance(mode, str) else "invalid",
             error=str(exc)[:600], elapsed_seconds=round(time.monotonic() - started, 3))
        return 1


if __name__ == "__main__":
    mode = globals().get("DEMO_MODE", sys.argv[1] if len(sys.argv) > 1 else "cpu")
    raise SystemExit(main(mode))
