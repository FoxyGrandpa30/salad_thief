# Your first queued job

This job adds two 65,536-element integer arrays, checks every result against a
CPU reference, and repeats five times. The expected checksum is **67043328**.

| Mode | What it verifies |
| --- | --- |
| `cpu` | Real job delivery, container execution, calculation, and result return. |
| `gpu` | A real CUDA calculation on the first visible NVIDIA GPU, checked against the CPU reference. |

GPU mode fails if CUDA is unavailable; it never substitutes CPU computation.
There are brief pauses so you can see the running state. This is a functional
demonstration, not a stress test or performance benchmark.

## On a trusted home LAN

Use the latest project source on the **coordinator PC**, with Python 3.11+.
The basic demo works with the original boot USB. Laptop AC protection and
CPU-only USB enrollment require the updated image; follow the
[HP laptop guide](../../docs/HARDWARE_SUPPORT.md) for those profiles. The worker
downloads an official Python image pinned by SHA-256 on its first run.

1. Find the coordinator PC's LAN IPv4 address. Replace `192.168.1.10` below with
   that address. Run from the project directory:

   ```sh
   python3 -m pcgrid.demo prepare --host 0.0.0.0 \
     --worker-url http://192.168.1.10:8080 --allow-insecure-http --gpu
   ```

   This creates a **new** setup in `.local/startup-demo/` with private
   coordinator and worker credentials. Existing setups are preserved. If this
   directory already exists, reuse it with `start`; choose a different
   `--directory .local/another-demo` for a separate setup.

2. Copy `.local/startup-demo/startup-worker.json` to the removable configuration
   USB as `worker.json`. Its volume label must be `PCGRID_CFG`, as in
   [the USB instructions](../../image/README.md). Keep the file private.

   **Import this new file even if you have an older worker config.** It approves
   the demo's Python image and contains this coordinator's worker key.
   Keep `coordinator.json` on the coordinator PC.

3. Start the coordinator and queue the CPU check:

   ```sh
   python3 -m pcgrid.demo start
   ```

   Leave this terminal running. The job waits for a worker; the worker does not
   need to be online yet. Each `start` adds one new demo job. Older unfinished
   jobs remain in the queue.

4. Boot the worker USB on the other PC, configure its network, and import the
   new configuration USB. The worker starts and claims the job. The coordinator
   shows `queued`, `running`, then `succeeded` and the returned results.
   Round events arrive together after completion rather than streaming live.

The final event includes:

```json
{"event": "PASS", "mode": "cpu", "elements": 65536, "rounds": 5, "checksum": 67043328}
```

The full event also reports the device and elapsed time. That time includes the
deliberate pauses and, for GPU mode, first-use compilation overhead.

Plaintext HTTP exposes worker credentials to network observers. This example
is for a trusted private LAN. Use HTTPS across homes or untrusted networks.
If necessary, allow TCP 8080 through the coordinator's firewall from your LAN
only; do not forward this lab server to the public Internet.

## Then try the GPU calculation

First confirm `nvidia-smi` works through the worker console's GPU/status option.
In another terminal on the coordinator:

```sh
python3 -m pcgrid.demo queue --mode gpu
python3 -m pcgrid.manage status --config .local/startup-demo/coordinator.json JOB_ID
```

Replace `JOB_ID` with the identifier printed by `queue`. Repeat the status
command until it finishes. A successful result has `event: PASS`, `mode: gpu`,
the GPU name, and checksum `67043328`. Missing drivers, unsupported hardware,
or incorrect results produce a failed job with an error.

To watch the GPU calculation as the initial job instead, stop the coordinator
with Ctrl+C and run:

```sh
python3 -m pcgrid.demo start --mode gpu
```

Its three GPU data arrays total 768 KiB. CUDA's context and compiler use
additional memory. The container gets a 1 GiB RAM limit and normal PCGrid
filesystem, network, privilege, CPU, and timeout restrictions. Only the first
visible GPU is exercised.

For a custom setup directory, pass `--config PATH/coordinator.json` to `start`
and `queue`. A custom `--port` updates the default loopback worker/admin URL;
specify the matching port in a LAN `--worker-url` and in `pcgrid.manage --url`.

## Single-PC CPU test without the USB

On Linux with Python and Docker, in one terminal:

```sh
python3 -m pcgrid.demo prepare
python3 -m pcgrid.demo start
```

In another terminal, from the same project directory:

```sh
python3 -m pcgrid.worker --config .local/startup-demo/startup-worker.json --once
```

This default preparation generates a CPU-only config for the source worker.
The original NVIDIA USB image requires `prepare --gpu` as in the LAN example,
even for CPU jobs. The updated image also accepts CPU-only configurations.
Use separate setup directories when trying both examples.

## Validation

The CPU demo passed end to end through the HTTP coordinator and a separate
Docker worker. It was queued **before** the worker launched, verified all five
rounds, returned the expected checksum, and removed its container.

NVIDIA's official CUDA 12.8.93 `ptxas` compiled the GPU kernel offline for
`sm_86`, `sm_89`, and `sm_120` (RTX 3060, RTX 4090, and RTX 5090 architectures).
API signatures were checked against NVIDIA's CUDA 12.8 header. **Actual GPU
execution remains untested in this GPU-less environment.** Run it on your
hardware before claiming that physical GPU works.

Readable [job.py](job.py) source is transported as arguments to the pinned
Python container, split to fit the existing protocol. The job installs nothing
at runtime and has no network access. No custom image publication or USB
protocol change is required.
