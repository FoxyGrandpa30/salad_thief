#!/usr/bin/env python3
"""Boot the real ISO as removable USB under software QEMU, with BIOS or UEFI."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import time


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def qmp(path, commands):
    with socket.socket(socket.AF_UNIX) as sock:
        sock.settimeout(5)
        sock.connect(str(path))
        with sock.makefile("rwb") as stream:
            json.loads(stream.readline())
            for command in [{"execute": "qmp_capabilities"}, *commands]:
                stream.write(json.dumps(command).encode() + b"\n")
                stream.flush()
                while True:
                    result = json.loads(stream.readline())
                    if "error" in result:
                        raise RuntimeError(result["error"])
                    if "return" in result:
                        break


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--iso", type=Path, required=True)
    parser.add_argument("--firmware", choices=("bios", "uefi"), required=True)
    parser.add_argument("--output", type=Path, default=Path("build/boot-tests"))
    parser.add_argument("--timeout", type=int, default=300)
    args = parser.parse_args()
    iso = args.iso.resolve()
    if not iso.is_file():
        raise SystemExit("ISO does not exist")
    output = args.output.resolve() / args.firmware
    output.mkdir(parents=True, exist_ok=False)
    # A writable simulated internal disk helps detect accidental disk writes.
    disk = output / "internal-test.img"
    with disk.open("wb") as stream:
        stream.truncate(64 * 1024 * 1024)
    common = ["docker", "run", "--rm", "--user", f"{os.getuid()}:{os.getgid()}",
              "--network", "none", "--workdir", "/tmp",
              "--mount", f"type=bind,src={iso.parent},dst=/images,readonly",
              "--mount", f"type=bind,src={output},dst=/results"]
    subprocess.run(common + ["pcgrid-boot-tools", "mkfs.fat", "-n", "INTERNAL",
                              "/results/internal-test.img"], check=True)
    before = digest(disk)
    (output / "internal-disk-before.sha256").write_text(before + "\n")
    qemu = ["qemu-system-x86_64", "-machine", "q35", "-accel", "tcg", "-smp", "2",
            "-m", "4096", "-display", "none", "-serial", "file:/results/serial.log",
            "-qmp", "unix:/results/qmp.sock,server=on,wait=off", "-no-reboot",
            "-drive", f"if=none,id=live,format=raw,readonly=on,file=/images/{iso.name}",
            "-device", "qemu-xhci,id=xhci", "-device", "usb-storage,drive=live,removable=on,bootindex=1",
            "-drive", "file=/results/internal-test.img,format=raw,if=ide",
            "-nic", "user,model=e1000", "-boot", "order=c"]
    if args.firmware == "uefi":
        subprocess.run(common + ["pcgrid-boot-tools", "cp", "/usr/share/OVMF/OVMF_VARS_4M.fd",
                                  "/results/OVMF_VARS.fd"], check=True)
        qemu += ["-drive", "if=pflash,unit=0,format=raw,readonly=on,file=/usr/share/OVMF/OVMF_CODE_4M.fd",
                 "-drive", "if=pflash,unit=1,format=raw,file=/results/OVMF_VARS.fd"]
    name = "pcgrid-boot-" + args.firmware + "-" + str(os.getpid())
    with (output / "qemu.log").open("w") as log:
        process = subprocess.Popen(common + ["--name", name, "pcgrid-boot-tools", *qemu],
                                   stdout=log, stderr=log)
        try:
            deadline = time.monotonic() + args.timeout
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise RuntimeError("QEMU exited before boot completed; inspect qemu.log")
                serial = output / "serial.log"
                text = serial.read_text(errors="replace") if serial.exists() else ""
                text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]|\x1b.", "", text)
                if ("PCGrid offline container self-test failed" in text
                        or "PCGrid network service self-test failed" in text
                        or "Failed to start pcgrid-selftest" in text):
                    qmp(output / "qmp.sock", [{"execute": "screendump", "arguments": {
                        "filename": "/results/failure.ppm"}}])
                    raise RuntimeError("Guest container self-test failed; inspect serial.log")
                if ("Started pcgrid-console.service" in text
                        and "Reached target multi-user.target" in text
                        and "PCGRID_NETWORK_SERVICES_OK" in text
                        and "PCGRID_DOCKER_SELFTEST_OK" in text):
                    time.sleep(3)
                    qmp(output / "qmp.sock", [{"execute": "screendump", "arguments": {
                        "filename": "/results/console.ppm"}}])
                    print(f"PASS {args.firmware}: real USB ISO reached PCGrid console, multi-user target, working network services, and offline Docker selftest")
                    break
                time.sleep(2)
            else:
                if (output / "qmp.sock").exists():
                    qmp(output / "qmp.sock", [{"execute": "screendump", "arguments": {
                        "filename": "/results/timeout.ppm"}}])
                raise TimeoutError("Boot did not reach readiness; inspect serial.log and timeout.ppm")
        finally:
            subprocess.run(["docker", "stop", "--time", "5", name], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, check=False)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
    after = digest(disk)
    if after != before:
        raise AssertionError("Simulated internal disk changed during boot")
    (output / "internal-disk-check.txt").write_text("UNCHANGED sha256=" + after + "\n")
    print(f"PASS {args.firmware}: writable simulated internal disk was unchanged")


if __name__ == "__main__":
    main()
