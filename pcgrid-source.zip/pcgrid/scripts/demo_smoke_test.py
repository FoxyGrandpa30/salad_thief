#!/usr/bin/env python3
"""Real first-job test: launch demo queue, then connect a separate Docker worker."""

import hashlib
import json
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pcgrid import demo, manage
from pcgrid.coordinator import Config, Store


def main():
    # Pull the exact verified public image; no local registry or image publishing.
    subprocess.run(["docker", "pull", demo.DEMO_IMAGE], check=True)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    with tempfile.TemporaryDirectory(prefix="pcgrid-demo-test-") as directory:
        state = Path(directory) / "demo"
        config_path, worker_path = demo.prepare(state, port=port,
                                               worker_url=f"http://127.0.0.1:{port}")
        config = Config.load(config_path)
        with (Path(directory) / "coordinator.log").open("w+") as log:
            server = subprocess.Popen([sys.executable, "-m", "pcgrid.demo", "start", "--config",
                                       str(config_path), "--exit-after-job"], cwd=ROOT, stdout=log, stderr=log)
            try:
                for _ in range(100):
                    if server.poll() is not None:
                        raise RuntimeError("Demo coordinator exited before readiness")
                    try:
                        with urllib.request.urlopen(f"http://127.0.0.1:{port}/health", timeout=1) as response:
                            if json.load(response).get("status") == "ok":
                                break
                    except OSError:
                        time.sleep(0.1)
                else:
                    raise RuntimeError("Demo coordinator did not become ready")
                queued = Store(config).list_jobs()["jobs"]
                assert len(queued) == 1 and queued[0]["status"] == "queued", "No job waiting before worker launch"
                worker = subprocess.run([sys.executable, "-m", "pcgrid.worker", "--config", str(worker_path),
                                         "--once"], cwd=ROOT, capture_output=True, text=True, timeout=200)
                if worker.returncode:
                    raise RuntimeError("Worker failed: " + worker.stderr)
                if server.wait(timeout=15) != 0:
                    raise RuntimeError("Demo coordinator reported failure")
                result = Store(config).list_jobs(queued[0]["id"])
                events = [json.loads(line) for line in result["stdout"].splitlines()]
                assert result["status"] == "succeeded" and result["exit_code"] == 0, result
                assert events[-1]["event"] == "PASS" and events[-1]["mode"] == "cpu", events
                assert events[-1]["checksum"] == 67_043_328 and events[-1]["elements"] == 65536, events
                assert len([event for event in events if event["event"] == "PROGRESS"]) == 5, events
                token = manage.load(worker_path)["worker_token"]
                owner = hashlib.sha256(token.encode()).hexdigest()[:24]
                remaining = subprocess.check_output([
                    "docker", "ps", "-aq", "--filter", "label=pcgrid.owner=" + owner], text=True).strip()
                assert not remaining, "Demo container was not cleaned up"
                print("PASS: job queued before worker launch; actual Docker worker ran five rounds, verified 65,536 results, returned checksum 67043328, and removed its container.")
                print("GPU execution was not tested in this GPU-less environment.")
            except BaseException:
                log.flush()
                log.seek(0)
                print(log.read(), file=sys.stderr)
                raise
            finally:
                if server.poll() is None:
                    server.terminate()
                    try:
                        server.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        server.kill()
                        server.wait()


if __name__ == "__main__":
    main()
