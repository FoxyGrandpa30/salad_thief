#!/usr/bin/env python3
"""Run real coordinator -> Docker worker -> result tests. No GPU required."""

import argparse
import hashlib
import json
from pathlib import Path
import secrets
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pcgrid.manage import request, write_private


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--image", required=True, help="locally available approved image@sha256:digest with /bin/sh")
    args = parser.parse_args()
    subprocess.run(["docker", "image", "inspect", args.image], check=True, stdout=subprocess.DEVNULL)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    url = f"http://127.0.0.1:{port}"
    with tempfile.TemporaryDirectory(prefix="pcgrid-smoke-") as directory:
        state = Path(directory)
        admin_token, worker_token = secrets.token_urlsafe(32), secrets.token_urlsafe(32)
        coordinator = {"database": str(state / "jobs.sqlite3"), "host": "127.0.0.1", "port": port,
                       "admin_token": admin_token, "workers": {"smoke": worker_token},
                       "allowed_images": [args.image], "lease_seconds": 3}
        worker = {"coordinator_url": url, "worker_token": worker_token,
                  "allowed_images": [args.image], "gpu_enabled": False}
        write_private(state / "coordinator.json", coordinator)
        write_private(state / "worker.json", worker)
        with open(state / "coordinator.log", "w+") as log:
            process = subprocess.Popen([sys.executable, "-m", "pcgrid.coordinator", "--config",
                                        str(state / "coordinator.json")], cwd=ROOT, stdout=log, stderr=log)
            try:
                for _ in range(100):
                    if process.poll() is not None:
                        raise RuntimeError("Coordinator exited before readiness")
                    try:
                        with urllib.request.urlopen(url + "/health", timeout=1) as response:
                            if json.load(response).get("status") == "ok":
                                break
                    except OSError:
                        time.sleep(0.1)
                else:
                    raise RuntimeError("Coordinator failed readiness")
                cases = [
                    ("isolated execution", ["/bin/sh", "-c",
                        "test \"$(id -u)\" = 65534 && "
                        "! touch /pcgrid-readonly-probe 2>/dev/null && "
                        "test ! -e /var/run/docker.sock && "
                        "printf 'pcgrid-isolation-ok\\n'"], 20, 0, "pcgrid-isolation-ok"),
                    ("failed executable", ["/bin/sh", "-c", "printf 'intentional failure\\n' >&2; exit 7"],
                        20, 7, None),
                    ("timeout cleanup", ["/bin/sleep", "20"], 2, 124, None),
                    ("heartbeat renewal", ["/bin/sh", "-c", "sleep 5; printf 'heartbeat-ok\\n'"],
                        20, 0, "heartbeat-ok"),
                ]
                for name, command, timeout, exit_code, output in cases:
                    job = request(url + "/v1/jobs", admin_token, "POST", {
                        "image": args.image, "command": command, "timeout_seconds": timeout,
                        "cpus": 1, "memory_mb": 128, "gpu": False})
                    identifier = job["id"]
                    run = subprocess.run([sys.executable, "-m", "pcgrid.worker", "--config",
                                          str(state / "worker.json"), "--once"], cwd=ROOT,
                                         capture_output=True, text=True, timeout=60)
                    if run.returncode != 0:
                        raise AssertionError(f"{name}: worker exited {run.returncode}: {run.stderr}")
                    result = request(url + "/v1/jobs/" + identifier, admin_token)
                    if result.get("status") not in ("succeeded", "failed"):
                        raise AssertionError(f"{name}: unexpected job state: {result}; worker: {run.stderr}")
                    if exit_code is not None and result.get("exit_code") != exit_code:
                        raise AssertionError(f"{name}: unexpected exit: {result}; worker: {run.stderr}")
                    if output and output not in result.get("stdout", ""):
                        raise AssertionError(f"{name}: expected output absent: {result}")
                    if name == "timeout cleanup" and result.get("status") != "failed":
                        raise AssertionError(f"Timeout job should fail: {result}")
                    print(f"PASS {name}: status={result['status']} exit_code={result.get('exit_code')}")

                job = request(url + "/v1/jobs", admin_token, "POST", {
                    "image": args.image, "command": ["/bin/sh", "-c", "sleep 2; printf 'recovered\\n'"],
                    "timeout_seconds": 20, "cpus": 1, "memory_mb": 128, "gpu": False})
                endpoint = url + "/v1/jobs/" + job["id"]
                interrupted = subprocess.Popen([sys.executable, "-m", "pcgrid.worker", "--config",
                                                str(state / "worker.json"), "--once"], cwd=ROOT,
                                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                try:
                    for _ in range(100):
                        if request(endpoint, admin_token)["status"] == "running":
                            break
                        if interrupted.poll() is not None:
                            raise AssertionError("Recovery worker exited before claiming")
                        time.sleep(0.1)
                    else:
                        raise AssertionError("Recovery worker did not claim")
                finally:
                    interrupted.terminate()
                    try:
                        interrupted.wait(timeout=30)
                    except subprocess.TimeoutExpired:
                        interrupted.kill()
                        interrupted.wait()
                for _ in range(60):
                    if request(endpoint, admin_token)["status"] == "queued":
                        break
                    time.sleep(0.1)
                else:
                    raise AssertionError("Interrupted job was not requeued after lease expiry")
                resumed = subprocess.run([sys.executable, "-m", "pcgrid.worker", "--config",
                                          str(state / "worker.json"), "--once"], cwd=ROOT,
                                         capture_output=True, text=True, timeout=60)
                result = request(endpoint, admin_token)
                if (resumed.returncode != 0 or result["status"] != "succeeded"
                        or result["attempts"] != 2 or "recovered" not in result["stdout"]):
                    raise AssertionError(f"Interrupted job recovery failed: {result}; {resumed.stderr}")
                print("PASS worker interruption: expired lease recovered on attempt 2")
                remaining = subprocess.check_output([
                    "docker", "ps", "-aq", "--filter",
                    "label=pcgrid.owner=" + hashlib.sha256(worker_token.encode()).hexdigest()[:24]],
                    text=True).strip()
                if remaining:
                    raise AssertionError("PCGrid-managed container remains after tests: " + remaining)
            except BaseException:
                log.flush()
                log.seek(0)
                print(log.read(), file=sys.stderr)
                raise
            finally:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()


if __name__ == "__main__":
    main()
