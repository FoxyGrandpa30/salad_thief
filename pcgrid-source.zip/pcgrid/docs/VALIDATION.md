# Validation record

## Application checks completed in this workspace

- `python3 -m unittest discover -v`: **76 tests passed**, zero skipped. Covers
  HTTP authentication, input limits, concurrent exclusive claims, GPU/resource
  matching, heartbeat renewal, expired leases, stale completion rejection,
  attempt limits, queue persistence, credential-file permissions, redirect
  refusal, worker shutdown/cleanup, and malformed responses.
- Added hardware-vendor discovery and laptop-profile tests. AC policy tests
  cover unknown/unreadable power, no claims while offline, power loss during
  pulling/execution, cancellation cleanup, and resumption after AC returns.
- An additional real Docker check cancelled a running container after simulated
  AC loss, confirmed its removal and no completion submission, and left the
  worker resumable. The cloud has no physical laptop power sensor; HP sensor
  behavior remains unrun.
- The startup demo adds tests for source transport, private configuration,
  authenticated queuing, exact vector/checksum verification, unavailable-CUDA
  failure without CPU fallback, and GPU resource cleanup.
- `python3 scripts/demo_smoke_test.py`: **passed**. The job was queued before
  the worker launched; a separate real Docker worker verified 65,536 results
  in each of five rounds, returned checksum `67043328`, and removed its container.
- The GPU demo's PTX compiled offline for `sm_86`, `sm_89`, and `sm_120` using
  NVIDIA's official CUDA 12.8.93 assembler. Driver signatures were checked against
  NVIDIA's CUDA 12.8 header. These are compilation/API checks; physical GPU
  execution remains **unrun**.
- `python3 scripts/smoke_test.py --image docker.io/library/debian@sha256:62bd423aeee912639ca8ee681c2b762cb3e25137e0a92b20be455898a9f034ad`:
  **5 real Docker cases passed** through the HTTP coordinator and a separate
  worker process:
  1. Successful executable returned expected text, ran as UID 65534, could not
     write the container root filesystem, and could not see the Docker socket.
  2. A deliberately failed executable returned exit code 7 and a failed job.
  3. A sleeping executable was stopped at its timeout, returned exit code 124,
     and left no container owned by the test worker.
  4. A longer-running executable completed while its three-second lease was
     repeatedly renewed by heartbeats.
  5. A worker was interrupted after claiming a job; the lease expired, the job
     was requeued, and a restarted worker completed it on attempt two.

An initial real Docker run exposed an incompatible local log-driver setting;
the worker was corrected to disable log compression when retaining one log
file. The complete smoke test passed again after the fix and subsequent input
validation changes.

## Operating-system image

The corrected `dist/pcgrid-live-amd64.iso` was built successfully with the saved
`image/build.sh` command. Its SHA-256 sidecar check passed. The image includes
Linux 6.12.113, compiled NVIDIA open kernel modules 595.112.07, NVIDIA Container
Toolkit 1.20.1, Docker engine/client 26.1.5, AppArmor tooling, and Intel/AMD
display firmware 20250410-2. The display firmware does not add Intel/AMD
compute runtimes.

Both tests below passed using software QEMU, with the actual ISO attached as a
removable USB device and a separate writable simulated internal FAT disk:

```sh
python3 scripts/boot_smoke.py --iso dist/pcgrid-live-amd64.iso --firmware bios --output build/boot-tests-hp-network-final --timeout 600
python3 scripts/boot_smoke.py --iso dist/pcgrid-live-amd64.iso --firmware uefi --output build/boot-tests-hp-network-final --timeout 600
```

For **both BIOS and UEFI**, the guest reached the physical console and multi-user
target. D-Bus and NetworkManager were active and responded to an `nmcli`
request (`PCGRID_NETWORK_SERVICES_OK`), then the offline container job executed
using the actual worker runtime. The job ran as a nonroot user, wrote its
temporary directory, returned `PCGRID_DOCKER_SELFTEST_OK`, and was removed. Docker used `overlay2` on
its dedicated RAM-backed `tmpfs`. The simulated internal disk's SHA-256 was
unchanged after each boot.

Console screenshots: [BIOS](boot-console-bios.png), [UEFI](boot-console-uefi.png).
Full logs and disk-hash evidence remain under `build/boot-tests-hp-network-final/` in the
development workspace.

The first image booted but failed its container test because Debian's separate
Docker CLI package was missing. The image was corrected to include `docker-cli`
and AppArmor tooling. NVIDIA's transitional `nvidia-smi` package also lacked the
actual executable; the correct `nvidia-driver-cuda` package was added. Required
binaries and NVIDIA library loading now pass pre-seal checks, and the rebuilt
image passed both complete boot tests.

A final log review also caught failed D-Bus and NetworkManager startup: copying
an overlay from a private workspace had propagated restrictive directory modes
and ownership into the OS. Overlay installation now normalizes public OS
permissions and root ownership, pre-seal checks test access as the message-bus
user, and the boot test requires responding network services as well as Docker.

Independent inspection of the final squashfs confirmed the exact current worker
and hardware-diagnostic source, required runtime binaries, public OS directory
permissions, and NVIDIA runtime configuration. No worker credential, build-proxy certificate, DKMS signing private key, or saved random
seed was embedded. Machine identity files were cleared before sealing. The
cached rebuild path was exercised, including a copied worker change propagating
into a rebuilt image; the final image contains the original project source.

These VMs have **no NVIDIA adapter**. GPU-specific CDI generation is conditional
on an NVIDIA device being present. The NVIDIA persistence daemon may fail on
these GPU-less VMs; physical NVIDIA readiness is not claimed. The successful
offline workload tests demonstrate CPU container execution only. Responding
network services do not certify physical Wi-Fi hardware or Internet connectivity.
Secure Boot was disabled in the UEFI test; Secure Boot support is outside this prototype.

## Hardware and deployment checks not performed

- No NVIDIA GPU is available in this cloud environment. RTX 3050 Laptop,
  RTX 3060, RTX 4090, and RTX 5090 device detection and real CUDA computation remain **unrun**.
- Physical USB boot, Wi-Fi compatibility, firmware behavior, and preservation
  of an actual PC's installed OS remain **unrun**.
- No public HTTPS endpoint, reverse proxy, multi-home Internet fleet, or payment
  integration has been deployed or tested.
- No external security audit or hostile-code isolation certification has been
  performed. Use trusted machines and approved nonsensitive workloads only.

The source is editable locally. No GitHub commits, branches, or pushes were
created as part of this implementation.
