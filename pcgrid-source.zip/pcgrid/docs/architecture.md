# Architecture and deployment boundary

```mermaid
flowchart LR
    A[Administrator CLI] -->|Authenticated job submission| C[Coordinator API]
    C --> D[(SQLite queue)]
    W[USB worker / Docker host] -->|Outbound claims and heartbeats| C
    W --> J[Fresh restricted job container]
    J -->|Bounded stdout and stderr| W
    W -->|Authenticated result and lease token| C
```

The coordinator is a small threaded Python HTTP service. A job transitions from
`queued` to `running` to `succeeded` or `failed`. Claims are serialized inside
SQLite write transactions. Each claim gets a new random lease token. Expired
leases are requeued when the next claim or job-status query runs; after three
attempts, expiration is terminal. Heartbeats renew leases. Results from previous
attempts cannot overwrite a subsequent result.

The worker runs one job at a time, renews its lease while Docker pulls and
executes, and removes its container when it finishes, times out, loses its
lease, or shuts down. Restart cleanup removes containers owned by the same
worker credential. This prevents local leftovers; it is not exactly-once
execution across a distributed network.

Both sides approve exact image digests. The worker overrides image entrypoints
with the supplied executable and does not accept host shell instructions,
arbitrary Docker flags, mounts, device paths, or privileged execution requests.
The submitted executable still has whatever capabilities its approved image,
container policy, and optional NVIDIA driver expose. Approval must mean that
you trust the image contents and the person submitting the workload.

Transport is HTTP only inside the coordinator process. Deploy an HTTPS reverse
proxy for actual remote operation. Worker requests verify HTTPS certificates
and refuse redirects rather than forwarding credentials to another host.
Authentication is simple per-worker bearer credentials, provisioned offline;
there is no public enrollment flow. Revocation is removal from the coordinator
configuration followed by a coordinator restart.

Future changes should keep worker protocol versions, backward compatibility,
database migrations, fleet updates, result artifacts, and image distribution
explicit. Adding payments or untrusted tenants changes the security and
operational requirements; it is not just another dashboard feature.
