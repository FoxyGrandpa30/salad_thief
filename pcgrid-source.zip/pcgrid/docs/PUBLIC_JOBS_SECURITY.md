# Public jobs: current boundary and release gates

**Public, untrusted jobs remain unsupported.** PCGrid currently assumes trusted
operators, trusted participants, and approved nonsensitive workloads. No public
submission service, worker-enforced task catalog, or VM execution backend has
been implemented. Adding hardware support does not change this security status.

## What the prototype enforces today

- Administrator and worker credentials are separate; workers authenticate to
  the coordinator. Remote worker HTTPS verifies certificates; plaintext HTTP
  requires explicit opt-in for a trusted lab network.
- Both sides approve exact container-image digests. Each job gets a fresh
  container with no job networking, a read-only root filesystem, an unprivileged
  user, dropped capabilities, no new privileges, and no requested host-folder or
  Docker-socket mounts. GPU runtimes deliberately inject devices and drivers.
- Jobs have CPU, RAM, process-count, time, and output limits. Containers are
  removed after execution, cancellation, or timeout when Docker remains usable.
- The live image uses RAM-backed storage and avoids mounting internal disks.

These are useful controls, not certification that customer programs are benign.

## Concrete gaps

1. **Approved image does not mean approved code.** The job API accepts arbitrary
   executable arguments. An approved Python image with `python -c`, or a shell
   in an approved Debian image, still runs arbitrary submitted code. The image
   digest identifies bytes; a signature identifies a signer. Neither proves
   harmlessness. Static scans and test runs can miss new exploits or delayed
   behavior. There is no scanner that can guarantee arbitrary jobs are safe.
2. **The host kernel and GPU driver are shared.** A container or driver exploit
   could compromise the host. Leaving an internal disk unmounted does not
   protect it after a sufficiently privileged host compromise. A live USB is
   not an isolation boundary between a hostile job and the laptop's hardware.
3. **GPU resource limits are incomplete.** CPU/RAM limits do not enforce VRAM,
   GPU utilization, or power limits. GPU access can freeze the display or hang a
   driver beyond reliable process cleanup. Integrated GPUs also share system
   RAM. Current NVIDIA jobs expose all GPUs on the worker.
4. **Image handling is also an attack surface.** Docker pulls and unpacks image
   layers, and GPU runtime hooks operate with host privileges, before normal
   container restrictions take effect. Untrusted images must not be approved
   just because a short execution or malware scan passed.
5. **The coordinator is a private prototype.** Its administrator job endpoint
   must not become a customer endpoint or receive public administrator keys.
   Public authentication, tenant separation, abuse controls, and operational
   recovery require additional implementation and review.

## Recommended first public product: fixed functions, bounded data

Offer a small catalog of operator-maintained operations, such as one reviewed
inference model. Customers select an operation and supply validated data; they
cannot choose images, entrypoints, source code, shell commands, plugins,
arbitrary download URLs, or executable model formats. Do not enable remote
model code or unsafe object deserialization for public input.

Before release, implement and test these **currently planned** controls:

- Workers enforce a trusted task catalog: exact image digest, fixed entrypoint,
  typed input schema, permitted backend, and bounded resources. Coordinator-only
  validation is insufficient. Inputs must never become shell or Python code.
- Build and review artifacts in separate infrastructure; scan dependencies and
  images, retain provenance, approve versions, and support rapid revocation.
  Keep the kernel, Docker, GPU toolkit, drivers, and parsers patched.
- Add customer authentication, quotas, rate limits, isolated storage, bounded
  outputs, audit records, and separate administrator access. Test malformed and
  adversarial inputs against each supported function and parser.
- Keep job networking disabled. If an operation needs data retrieval, prefer a
  controlled broker. Any future egress policy must block household LANs,
  private/link-local addresses, metadata services, and IPv6 equivalents, including
  access through DNS rebinding. Internet filtering alone does not protect a LAN.
- Validate pause/kill behavior, memory exhaustion, driver failures, GPU resets,
  thermal/battery behavior, and recovery on each supported hardware profile.
- Quarantine artifacts or inputs associated with suspected exploitation or
  driver crashes rather than automatically retrying them across the fleet.

Fixed functions reduce the attack surface; malicious inputs and parser bugs
remain possible. Independent security review and incident-response procedures
are required before representing the service as suitable for public use.

## Arbitrary customer code requires a separate execution design

Use disposable VMs for stronger CPU isolation, with minimal virtual devices,
strict host-side networking, no personal disks or host-directory shares, and
tested teardown. This VM backend is not present in PCGrid today.

GPU execution needs separately validated virtualization: for example, QEMU/KVM
with a dedicated discrete GPU assigned through VFIO and functioning IOMMU
isolation. Check actual device groups, reset behavior, firmware, and driver
support. Do not bypass unsuitable grouping with an ACS override and call it
isolated. GPU passthrough still leaves hypervisor, VFIO, firmware, and hardware
risks; it does not create a zero-risk environment.

A laptop's integrated or only display GPU may not support suitable passthrough
while the host remains usable. GPU-capable hardware is not automatically safe
hardware for arbitrary public code. Refuse that execution mode on unsupported
profiles. Firecracker, gVisor, and generic "microVM" labels are not universal
GPU isolation solutions. Start public-code evaluation on expendable dedicated
machines, not a primary laptop containing personal data.

## Trust works in both directions

Protecting the contributor does not protect customer data from that contributor.
An owner controlling a worker can generally inspect workloads, VM memory, model
files, and results, or falsify completed work. Ordinary containers and VMs do
not solve this. Use nonsensitive data with an explicit trust agreement, a vetted
fleet, or an appropriately evaluated confidential-computing design. Result
verification and fraud prevention are separate requirements from job isolation.
