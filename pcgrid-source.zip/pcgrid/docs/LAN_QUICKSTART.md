# First two-PC test on a trusted home LAN

This lab mode uses plaintext HTTP. Worker bearer tokens are visible to anyone
able to observe the connection. Use only a trusted private network; keep this
test endpoint off the public Internet. HTTPS is required for actual remote use.

## Coordinator PC

Use a Linux PC with Python 3.11+. The coordinator does not need a GPU or Docker
unless you also run a worker there. From the source checkout:

```sh
IMAGE=docker.io/library/debian@sha256:62bd423aeee912639ca8ee681c2b762cb3e25137e0a92b20be455898a9f034ad
python3 -m pcgrid.manage init --directory .local/lan --host 0.0.0.0 --image "$IMAGE"
```

Find the coordinator PC's LAN IPv4 address. In the next command, replace
`192.168.1.10` with that actual address:

```sh
python3 -m pcgrid.manage add-worker --directory .local/lan --id gpu-pc1 \
  --url http://192.168.1.10:8080 --gpu --allow-insecure-http
python3 -m pcgrid.coordinator --config .local/lan/coordinator.json
```

Keep the coordinator running. If its firewall blocks the connection, allow TCP
8080 only from your trusted LAN. No router port forwarding is needed for this
same-LAN test. Protect `.local/lan/coordinator.json`; it holds administrator and
worker credentials.

## Worker PC

Write the ISO to a spare boot USB. Put this PC's generated
`.local/lan/gpu-pc1.json` on a separate configuration USB as `worker.json`, using
the volume label and instructions in [image/README.md](../image/README.md).

Boot the live USB, configure its network, and import the configuration USB.
Check the GPU and worker status from the console. The initial image downloads
and unpacked job images use RAM; Internet access is needed to pull the approved
image from its registry. No personal folders are shared with jobs.

## Submit a CPU job first

In another terminal on the coordinator PC, from the source checkout:

```sh
python3 -m pcgrid.manage submit --config .local/lan/coordinator.json \
  -- /bin/sh -c 'id; printf "first job completed\n"'
python3 -m pcgrid.manage jobs --config .local/lan/coordinator.json
python3 -m pcgrid.manage status --config .local/lan/coordinator.json JOB_ID
```

Admin commands contact loopback on the coordinator. Replace `JOB_ID` with the
identifier returned by submission. Expected result: status `succeeded`, exit
code `0`, UID `65534`, and the requested text in stdout. Then perform the pinned
CUDA-image test in the root README to validate actual GPU computation.

Register each additional worker with a different `--id` and token. Restart the
coordinator after registration. Pause a worker using its console before shutting
it down. Its downloaded images and imported credentials disappear after reboot;
completed results remain in the coordinator's SQLite database.
