# Hardware support and the HP laptop test

The initial HP ENVY 17-cw1023cl target has the following **user-reported** hardware:

- Intel Core Ultra 7 155U, x86-64.
- 32 GB system RAM.
- NVIDIA GeForce RTX 3050 Laptop GPU with 4 GB dedicated VRAM.

The RTX 3050 uses the same CUDA backend as the larger NVIDIA cards in this
project. Its Ampere architecture is covered by the demo kernel's offline
`sm_86` compilation check. That is not a physical HP test: boot, Wi-Fi, GPU
initialization, AC reporting, and CUDA execution still need checking on the PC.
The 4 GB VRAM budget limits workloads even though system RAM is 32 GB.

## Current hardware matrix

| Hardware | Current status | Additional work |
| --- | --- | --- |
| Linux x86-64 CPU | Implemented; real Docker demo and emulated USB boots tested | Validate each PC's firmware, network, power and boot behavior |
| RTX 3050 Laptop through supported high-end NVIDIA cards | CUDA backend, NVIDIA driver and small GPU demo included | Physical GPU tests; workload-specific memory and architecture checks |
| Older or unusual NVIDIA devices | PCI discovery can report them; current open driver is not universal | Supported legacy driver image and compatible workload builds where necessary |
| Intel integrated/Arc graphics | Discovery and CPU fallback implemented; Intel/AMD display firmware included | Intel compute runtime such as Level Zero/OpenCL/SYCL, device access, and matching jobs |
| AMD integrated/discrete graphics | Discovery and CPU fallback implemented; display firmware included | Supported ROCm/OpenCL/Vulkan runtime and matching workload implementations |
| Future cards, including proposed 5090-class variants | No automatic certification from a model name | Verify actual device ID, driver support, runtime and kernel execution |

The USB image is x86-64. ARM PCs and Apple Silicon need separate OS/runtime
builds. Discovery of an Intel/AMD adapter does not enable CUDA or certify GPU
execution. The diagnostic distinguishes implemented backends from driver
discovery; a real functional job is the final GPU check.

Jobs currently use `gpu: true` specifically for **NVIDIA CUDA**. They do not yet
declare Intel/AMD backend requirements or minimum VRAM. Before wider scheduling,
add explicit backend, architecture, memory and workload-version matching to
both worker and coordinator. Existing CPU/RAM quotas do not limit GPU VRAM,
power draw, utilization, or the damage from a hung driver.

## Laptop profiles implemented

Both profiles limit jobs to one CPU's worth of processing, 1 GiB host RAM, and
300 seconds maximum requested time. The startup demo requests 180 seconds and
fits these limits.

- `laptop-cpu`: CPU jobs only, with AC power required.
- `laptop-nvidia`: CPU and NVIDIA CUDA jobs, with AC power required.

Unknown, unreadable, or offline AC status prevents claims. AC loss during work
cancels the local container and sends no completion; the coordinator can retry
after the lease expires. Restoring AC allows claims again. This restarts work
rather than checkpointing it. Power checks can be delayed by an in-flight
heartbeat request and Docker cleanup; this is not a hard electrical interlock.
Temperature, GPU wattage, fan control, hard VRAM limits, and thermal shutdown
management have not been implemented. These profiles are for trusted tests.

## First test on the HP

Use the **updated** ISO from this release. Earlier ISOs do not enforce the new
AC policy. The updated console includes **Show hardware, power and storage
diagnostics**. Secure Boot remains unsupported; follow the main USB guide and
have the BitLocker recovery key available before changing firmware settings.

On the coordinator PC, replace `192.168.1.10` with its LAN address:

```sh
python3 -m pcgrid.demo prepare --directory .local/hp-envy \
  --profile laptop-nvidia --host 0.0.0.0 \
  --worker-url http://192.168.1.10:8080 --allow-insecure-http
python3 -m pcgrid.demo start --config .local/hp-envy/coordinator.json
```

This is plaintext HTTP for a trusted LAN only. Use HTTPS for remote deployment.
Import `.local/hp-envy/startup-worker.json` as `worker.json` from the private
`PCGRID_CFG` configuration USB. Connect AC, configure the network, and import it
from the worker console. Verify diagnostics reports AC online and GPU status
shows the expected RTX 3050 and approximately 4 GB VRAM.

Run the CPU startup job first. Then, on the coordinator:

```sh
python3 -m pcgrid.demo queue --config .local/hp-envy/coordinator.json --mode gpu
python3 -m pcgrid.manage status --config .local/hp-envy/coordinator.json JOB_ID
```

Both successful modes return checksum **67043328**. GPU mode must say `gpu` and
name the real card; it does not silently use the CPU. Its three data arrays use
768 KiB of VRAM, with additional CUDA context/compiler overhead. First image
downloads use RAM-backed storage and require registry access.

For a non-NVIDIA laptop, choose `--profile laptop-cpu`; its integrated GPU is not
advertised as a CUDA worker. Do not add `--gpu` to that profile.

A full queued test needs a reachable coordinator while the laptop boots the
worker USB. It can be another ordinary PC; it does not need a GPU. With only
one PC, the USB's offline container self-test and NVIDIA status check are useful
first steps. Alternatively run coordinator and worker together from an existing
Linux installation using the source; the USB does not run alongside Windows.

The built-in `python3 -m pcgrid.hardware` diagnostic reports CPU count, RAM, PCI
GPU vendor/device IDs, NVIDIA model/driver/VRAM when visible, and AC status. It
does not request hardware serials, UUIDs, credentials, or process lists.

**Do not use this primary laptop for arbitrary public code.** Wider hardware
support does not change the boundary described in
[PUBLIC_JOBS_SECURITY.md](PUBLIC_JOBS_SECURITY.md).
