import http.server
import io
import json
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

from pcgrid import worker


IMAGE = "debian@sha256:" + "a" * 64
TOKEN = "test-worker-token-with-sufficient-length"


def config(**changes):
    raw = {"coordinator_url": "http://127.0.0.1:8080", "worker_token": TOKEN, "allowed_images": [IMAGE]}
    raw.update(changes)
    return worker.validate_config(raw)


def job(**changes):
    raw = {
        "id": "0123456789abcdef0123456789abcdef", "lease_token": "test-lease-token",
        "lease_seconds": 30, "image": IMAGE, "command": ["/bin/echo", "hello"],
        "timeout_seconds": 60, "cpus": 1, "memory_mb": 512, "gpu": False,
    }
    raw.update(changes)
    return raw


class ConfigTests(unittest.TestCase):
    def test_remote_http_requires_explicit_opt_in(self):
        with self.assertRaises(worker.WorkerError):
            config(coordinator_url="http://192.168.1.20:8080")
        self.assertTrue(config(coordinator_url="http://192.168.1.20:8080", allow_insecure_http=True)["allow_insecure_http"])
        self.assertEqual(config(coordinator_url="https://compute.example.com")["coordinator_url"], "https://compute.example.com")

    def test_origin_cannot_embed_credentials_or_change_api_path(self):
        for url in ("https://secret:token@example.com", "https://example.com/api", "https://example.com?token=x", "file:///tmp/foo"):
            with self.subTest(url=url), self.assertRaises(worker.WorkerError):
                config(coordinator_url=url)

    def test_digest_and_numeric_limits_are_checked(self):
        for change in ({"allowed_images": ["debian:latest"]}, {"max_cpus": True}, {"max_cpus": 10 ** 400}, {"max_cpus": float("nan")}, {"gpu_enabled": "yes"}, {"require_ac_power": "yes"}, {"require_ac_power": 1}):
            with self.subTest(change=change), self.assertRaises(worker.WorkerError):
                config(**change)

    def test_ac_requirement_defaults_to_false_for_existing_configs(self):
        self.assertFalse(config()["require_ac_power"])
        self.assertTrue(config(require_ac_power=True)["require_ac_power"])

    def test_worker_tokens_match_coordinator_header_limits(self):
        for token in ("short", "a" * 1018, "a" * 24 + "\n", "\u00e9" * 24, "\x00" * 24):
            with self.subTest(token_length=len(token)), self.assertRaises(worker.WorkerError):
                config(worker_token=token)

    def test_credential_file_must_not_be_readable_by_other_users(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "worker.json"
            path.write_text(json.dumps(config()))
            path.chmod(0o644)
            with self.assertRaises(worker.WorkerError):
                worker.load_config(path)
            path.chmod(0o600)
            self.assertEqual(worker.load_config(path)["worker_token"], TOKEN)


class DockerTests(unittest.TestCase):
    def test_command_locks_down_host_access_and_keeps_job_arguments_after_image(self):
        spec = job(command=["/bin/echo", "--privileged", "$(touch /host/file)"])
        argv = worker.container_command(spec, "pcgrid-test", "owner")
        before, after = argv[:argv.index(IMAGE)], argv[argv.index(IMAGE) + 1:]
        self.assertEqual(after, spec["command"][1:])
        self.assertNotIn("--privileged", before)
        self.assertNotIn("--volume", before)
        self.assertEqual(before[before.index("--network") + 1], "none")
        self.assertIn("--read-only", before)
        self.assertEqual(before[before.index("--cap-drop") + 1], "ALL")
        self.assertEqual(before[before.index("--user") + 1], "65534:65534")
        self.assertIn("--entrypoint=/bin/echo", before)
        self.assertIn("pcgrid.managed=true", before)

    def test_gpu_requires_both_local_permission_and_job_request(self):
        spec = job(gpu=True)
        with self.assertRaises(worker.WorkerError):
            worker.validate_job(spec, config())
        worker.validate_job(spec, config(gpu_enabled=True))
        argv = worker.container_command(spec, "pcgrid-test", "owner")
        self.assertEqual(argv[argv.index("--gpus") + 1], "all")
        self.assertNotIn("--gpus", worker.container_command(job(), "pcgrid-test", "owner"))

    def test_invalid_unicode_command_is_rejected_without_a_crash(self):
        with self.assertRaises(worker.WorkerError):
            worker.validate_job(job(command=["/bin/echo", "\ud800"]), config())

    @patch("pcgrid.worker._command")
    def test_success_collects_output_and_removes_container_and_volumes(self, command):
        command.side_effect = [
            (0, "container-id", ""), (0, "container-name", ""), (0, "false 0", ""),
            (0, "hello\n", "diagnostic\n"), (0, "removed", ""),
        ]
        result = worker.DockerRuntime(TOKEN).execute(job(), threading.Event())
        self.assertEqual(result, {"exit_code": 0, "stdout": "hello\n", "stderr": "diagnostic\n"})
        last_argv = command.call_args_list[-1].args[0]
        self.assertEqual(last_argv[:4], ["docker", "rm", "--force", "--volumes"])

    @patch("pcgrid.worker._command")
    def test_timeout_returns_failure_and_cleans_up(self, command):
        command.side_effect = [worker.RuntimeTimeout("timeout"), (0, "removed", "")]
        result = worker.DockerRuntime(TOKEN).execute(job(), threading.Event())
        self.assertEqual(result["exit_code"], 124)
        self.assertEqual(command.call_args_list[-1].args[0][1], "rm")

    @patch("pcgrid.worker._command")
    def test_lost_lease_terminates_execution_and_cleans_up(self, command):
        command.side_effect = [
            (0, "created", ""), (0, "started", ""), worker.LeaseLost("revoked"), (0, "removed", ""),
        ]
        with self.assertRaises(worker.LeaseLost):
            worker.DockerRuntime(TOKEN).execute(job(), threading.Event())
        self.assertEqual(command.call_args_list[-1].args[0][1], "rm")

    @patch("pcgrid.worker._command")
    def test_uncertain_cleanup_is_a_fatal_error(self, command):
        command.side_effect = [worker.RuntimeTimeout("timeout"), worker.RuntimeTimeout("daemon stuck")]
        with self.assertRaises(worker.CleanupError):
            worker.DockerRuntime(TOKEN).execute(job(), threading.Event())

    @patch("pcgrid.worker._command")
    def test_startup_cleanup_is_scoped_to_this_worker(self, command):
        command.side_effect = [(0, "0123456789ab\nfedcba987654\n", ""), (0, "removed", "")]
        runtime = worker.DockerRuntime(TOKEN)
        runtime.cleanup_stale()
        listing = command.call_args_list[0].args[0]
        self.assertIn("label=pcgrid.owner=" + runtime.owner, listing)
        self.assertEqual(command.call_args_list[1].args[0][-2:], ["0123456789ab", "fedcba987654"])


class ExecutionTests(unittest.TestCase):
    def test_rejected_image_is_reported_without_executing_it(self):
        api, runtime = Mock(), Mock()
        api.post.return_value = {"job": job(image="evil@sha256:" + "b" * 64)}
        self.assertTrue(worker.Worker(config(), api=api, runtime=runtime).run_once())
        runtime.execute.assert_not_called()
        path, result = api.post.call_args.args
        self.assertTrue(path.endswith("/result"))
        self.assertEqual(result["exit_code"], 125)

    def test_local_caps_are_advertised_and_enforced(self):
        api, runtime = Mock(), Mock()
        api.post.return_value = {"job": job(cpus=3)}
        worker.Worker(config(), api=api, runtime=runtime).run_once()
        payload = api.post.call_args_list[0].args[1]
        self.assertEqual(payload["capabilities"]["max_cpus"], 2)
        self.assertFalse(payload["capabilities"]["gpu"])
        runtime.execute.assert_not_called()

    def test_large_unicode_and_control_character_output_is_bounded_before_submission(self):
        api, runtime = Mock(), Mock()
        api.post.return_value = {"job": job()}
        runtime.execute.return_value = {"exit_code": 0, "stdout": "\U0001f680" * 100000, "stderr": "\x00" * 100000}
        worker.Worker(config(), api=api, runtime=runtime).run_once()
        submitted = api.post.call_args.args[1]
        self.assertLess(len(json.dumps(submitted).encode()), 262144)
        self.assertEqual(len(submitted["stdout"]), worker.OUTPUT_BYTES)

    def test_once_claims_at_most_one_job(self):
        api, runtime = Mock(), Mock()
        api.post.return_value = None
        worker.Worker(config(), api=api, runtime=runtime).run(once=True)
        self.assertEqual(api.post.call_count, 1)
        runtime.cleanup_stale.assert_called_once()

    def test_failed_renewal_cancels_execution_before_short_lease_expires(self):
        api = Mock()
        api.post.side_effect = worker.WorkerError("HTTP 409")
        with worker.LeaseGuard(api, job(lease_seconds=1), threading.Event()) as lease:
            self.assertTrue(lease.cancelled.wait(0.9))
        self.assertLessEqual(api.post.call_args.kwargs["timeout"], 1 / 3)

    def test_shutdown_cancels_running_work_promptly(self):
        shutdown, api = threading.Event(), Mock()
        with worker.LeaseGuard(api, job(), shutdown) as lease:
            shutdown.set()
            self.assertTrue(lease.cancelled.wait(0.5))
        api.post.assert_not_called()


class LaptopSafetyTests(unittest.TestCase):
    def test_missing_or_unknown_ac_prevents_any_claim(self):
        for state in (False, None, "unknown"):
            with self.subTest(state=state):
                api, runtime = Mock(), Mock()
                agent = worker.Worker(config(require_ac_power=True), api=api, runtime=runtime,
                                      power_probe=lambda: state)
                with self.assertLogs(worker.LOG, level="INFO"):
                    self.assertFalse(agent.run_once())
                    self.assertFalse(agent.run_once())
                api.post.assert_not_called()
                runtime.execute.assert_not_called()

    def test_failed_power_probe_fails_closed(self):
        api, runtime = Mock(), Mock()
        probe = Mock(side_effect=OSError("power state unavailable"))
        agent = worker.Worker(config(require_ac_power=True), api=api, runtime=runtime, power_probe=probe)
        with self.assertLogs(worker.LOG, level="WARNING"):
            self.assertFalse(agent.run_once())
        api.post.assert_not_called()
        runtime.execute.assert_not_called()

    def test_ac_restore_resumes_claiming_and_logs_only_state_changes(self):
        api, runtime = Mock(), Mock()
        api.post.return_value = None
        power = {"state": False}
        agent = worker.Worker(config(require_ac_power=True), api=api, runtime=runtime,
                              power_probe=lambda: power["state"])
        with self.assertLogs(worker.LOG, level="INFO") as messages:
            agent.run_once()
            agent.run_once()
            api.post.assert_not_called()
            power["state"] = True
            agent.run_once()
            agent.run_once()
        self.assertEqual(api.post.call_count, 2)
        self.assertEqual(len(messages.records), 2)
        self.assertIn("AC power disconnected", messages.output[0])
        self.assertIn("AC power available", messages.output[1])
        self.assertFalse(agent.shutdown.is_set())
        # The local policy must never add unknown fields to the older API.
        caps = api.post.call_args.args[1]["capabilities"]
        self.assertNotIn("require_ac_power", caps)

    def test_legacy_config_does_not_probe_or_require_ac(self):
        api, runtime, probe = Mock(), Mock(), Mock(side_effect=AssertionError("must not probe"))
        api.post.return_value = None
        worker.Worker(config(), api=api, runtime=runtime, power_probe=probe).run_once()
        api.post.assert_called_once()
        probe.assert_not_called()

    def test_power_loss_during_claim_prevents_runtime_execution(self):
        api, runtime = Mock(), Mock()
        api.post.return_value = {"job": job()}
        probe = Mock(side_effect=[True, False])
        agent = worker.Worker(config(require_ac_power=True), api=api, runtime=runtime, power_probe=probe)
        with self.assertLogs(worker.LOG, level="INFO"):
            self.assertTrue(agent.run_once())
        api.post.assert_called_once()
        runtime.execute.assert_not_called()

    @patch("pcgrid.worker._command")
    def test_power_loss_cancels_pulling_or_running_and_forces_container_cleanup(self, command):
        for phase in ("create", "inspect"):
            with self.subTest(phase=phase):
                command.reset_mock()
                power = {"state": True}
                api = Mock()
                api.post.return_value = {"job": job()}

                def run(argv, deadline, cancelled=None):
                    if argv[1] == phase:
                        power["state"] = False
                        self.assertIsNotNone(cancelled)
                        self.assertTrue(cancelled.wait(0.8), "AC loss did not cancel the active operation")
                        raise worker.LeaseLost("AC power disconnected")
                    if argv[1] == "inspect":
                        return 0, "true 0", ""
                    return 0, "", ""

                command.side_effect = run
                agent = worker.Worker(config(require_ac_power=True), api=api,
                                      runtime=worker.DockerRuntime(TOKEN), power_probe=lambda: power["state"])
                with self.assertLogs(worker.LOG, level="INFO"):
                    self.assertTrue(agent.run_once())
                self.assertEqual(command.call_args_list[-1].args[0][:4],
                                 ["docker", "rm", "--force", "--volumes"])
                self.assertEqual(api.post.call_count, 1, "A cancelled job must not post a result or heartbeat")
                self.assertEqual(api.post.call_args.args[0], "/v1/jobs/claim")
                self.assertFalse(agent.shutdown.is_set())


class RedirectTests(unittest.TestCase):
    def test_deeply_nested_json_response_is_a_handled_request_failure(self):
        api = worker.API(config())
        response = io.BytesIO(b"[" * 10000 + b"0" + b"]" * 10000)
        response.status = 200
        api.opener = Mock()
        api.opener.open.return_value = response
        with self.assertRaises(worker.WorkerError):
            api.post("/v1/jobs/claim", {})

    def test_authentication_is_never_forwarded_to_a_redirect_destination(self):
        destination_hits = []

        class Destination(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                destination_hits.append(self.headers.get("Authorization"))
                self.send_response(200)
                self.end_headers()

            do_POST = do_GET

            def log_message(self, *args):
                pass

        destination = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Destination)
        location = f"http://127.0.0.1:{destination.server_port}/capture"

        class Redirect(http.server.BaseHTTPRequestHandler):
            def do_POST(self):
                self.send_response(302)
                self.send_header("Location", location)
                self.end_headers()

            def log_message(self, *args):
                pass

        origin = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Redirect)
        threads = [threading.Thread(target=server.serve_forever, daemon=True) for server in (origin, destination)]
        for thread in threads:
            thread.start()
        try:
            api = worker.API(config(coordinator_url=f"http://127.0.0.1:{origin.server_port}"))
            with self.assertRaisesRegex(worker.WorkerError, "HTTP 302"):
                api.post("/v1/jobs/claim", {})
            self.assertEqual(destination_hits, [])
        finally:
            for server in (origin, destination):
                server.shutdown()
                server.server_close()
            for thread in threads:
                thread.join(timeout=2)


if __name__ == "__main__":
    unittest.main()
