import concurrent.futures
import http.client
import json
import socket
import tempfile
import threading
import time
import unittest
from pathlib import Path

from pcgrid.coordinator import Config, Coordinator, Store


IMAGE = "docker.io/library/debian@sha256:" + "a" * 64
ADMIN = "administrator-" + "a" * 32
WORKER = "worker-one-" + "b" * 32
OTHER = "worker-two-" + "c" * 32


class CoordinatorTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.config = Config(Path(self.directory.name) / "jobs.db", ADMIN,
                             {"one": WORKER, "two": OTHER}, (IMAGE,), port=0)
        self.server = Coordinator(self.config)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.directory.cleanup()

    def request(self, method, path, token=None, data=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=5)
        headers = {}
        if token:
            headers["Authorization"] = "Bearer " + token
        if data is not None:
            headers["Content-Type"] = "application/json"
        connection.request(method, path, None if data is None else json.dumps(data), headers)
        response = connection.getresponse()
        payload = response.read()
        status = response.status
        connection.close()
        return status, json.loads(payload) if payload else None

    def submit(self, **fields):
        status, job = self.request("POST", "/v1/jobs", ADMIN,
                                   {"image": IMAGE, "command": ["echo", "hello"], **fields})
        self.assertEqual(status, 201, job)
        return job

    def claim(self, token=WORKER, **capabilities):
        status, data = self.request("POST", "/v1/jobs/claim", token,
                                    {"capabilities": capabilities} if capabilities else {})
        self.assertEqual(status, 200, data)
        return data["job"]

    def expire(self, job_id):
        with self.server.store.connect() as db:
            db.execute("UPDATE jobs SET lease_until=? WHERE id=?", (time.time() - 1, job_id))

    def test_health_and_authorization_separation(self):
        self.assertEqual(self.request("GET", "/health"), (200, {"status": "ok"}))
        self.assertEqual(self.request("GET", "/v1/jobs")[0], 401)
        self.assertEqual(self.request("GET", "/v1/jobs", WORKER)[0], 401)
        self.assertEqual(self.request("POST", "/v1/jobs/claim", ADMIN, {})[0], 401)
        self.assertEqual(self.request("GET", "/v1/jobs", "\u00ff")[0], 401)

    def test_submit_claim_heartbeat_and_success(self):
        job = self.submit(gpu=True, cpus=0.5, memory_mb=256)
        claimed = self.claim(gpu=True)
        self.assertEqual(claimed["id"], job["id"])
        self.assertEqual(claimed["gpu"], True)
        self.assertEqual(claimed["lease_seconds"], 30)
        lease = {"lease_token": claimed["lease_token"]}
        self.assertEqual(self.request("POST", f"/v1/jobs/{job['id']}/heartbeat", WORKER, lease)[0], 200)
        status, result = self.request("POST", f"/v1/jobs/{job['id']}/result", WORKER,
                                      {**lease, "exit_code": 0, "stdout": "hello\n", "stderr": ""})
        self.assertEqual((status, result["status"]), (200, "succeeded"))
        _, stored = self.request("GET", f"/v1/jobs/{job['id']}", ADMIN)
        self.assertEqual(stored["stdout"], "hello\n")
        self.assertEqual(stored["attempts"], 1)
        self.assertNotIn("lease_token", stored)
        self.assertEqual(self.request("POST", "/v1/jobs/claim", WORKER, {})[0], 204)

    def test_failed_exit_and_duplicate_completion(self):
        job = self.submit()
        claim = self.claim()
        payload = {"lease_token": claim["lease_token"], "exit_code": 17, "stderr": "bad input"}
        path = f"/v1/jobs/{job['id']}/result"
        self.assertEqual(self.request("POST", path, WORKER, payload)[0], 200)
        self.assertEqual(self.request("POST", path, WORKER, payload)[0], 409)
        _, stored = self.request("GET", f"/v1/jobs/{job['id']}", ADMIN)
        self.assertEqual(stored["status"], "failed")
        self.assertEqual(stored["exit_code"], 17)
        self.assertEqual(stored["attempts"], 1)

    def test_concurrent_claims_do_not_duplicate_assignment(self):
        self.submit()
        def claim(index):
            return self.request("POST", "/v1/jobs/claim", WORKER if index % 2 else OTHER, {})[0]
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
            statuses = list(pool.map(claim, range(16)))
        self.assertEqual(statuses.count(200), 1)
        self.assertEqual(statuses.count(204), 15)

    def test_one_active_job_per_worker(self):
        first = self.submit()
        second = self.submit()
        self.assertEqual(self.claim()["id"], first["id"])
        self.assertEqual(self.request("POST", "/v1/jobs/claim", WORKER, {})[0], 204)
        self.assertEqual(self.claim(OTHER)["id"], second["id"])

    def test_claim_matches_gpu_and_resource_capabilities(self):
        gpu_job = self.submit(gpu=True)
        large_job = self.submit(cpus=8, memory_mb=4096)
        small_job = self.submit()
        self.assertEqual(self.claim()["id"], small_job["id"])
        self.assertEqual(self.claim(OTHER, gpu=True)["id"], gpu_job["id"])
        with self.server.store.connect() as db:
            db.execute("UPDATE jobs SET status='failed' WHERE id IN (?,?)", (gpu_job["id"], small_job["id"]))
        self.assertEqual(self.request("POST", "/v1/jobs/claim", WORKER, {})[0], 204)
        self.assertEqual(self.claim(max_cpus=8, max_memory_mb=4096)["id"], large_job["id"])

    def test_claim_rejects_malformed_capabilities(self):
        for caps in ([], {"gpu": 1}, {"max_cpus": True}, {"max_cpus": 10 ** 400},
                     {"max_memory_mb": "large"}):
            self.assertEqual(self.request("POST", "/v1/jobs/claim", WORKER,
                                         {"capabilities": caps})[0], 400)

    def test_expiry_reassigns_and_rejects_stale_result(self):
        job = self.submit()
        old = self.claim()
        self.expire(job["id"])
        path = f"/v1/jobs/{job['id']}/result"
        self.assertEqual(self.request("POST", path, WORKER,
                         {"lease_token": old["lease_token"], "exit_code": 0})[0], 409)
        new = self.claim(OTHER)
        self.assertNotEqual(old["lease_token"], new["lease_token"])
        self.assertEqual(self.request("POST", f"/v1/jobs/{job['id']}/heartbeat", WORKER,
                         {"lease_token": old["lease_token"]})[0], 409)
        self.assertEqual(self.request("POST", path, OTHER,
                         {"lease_token": new["lease_token"], "exit_code": 0})[0], 200)
        _, stored = self.request("GET", f"/v1/jobs/{job['id']}", ADMIN)
        self.assertEqual(stored["attempts"], 2)
        self.assertEqual(stored["worker_id"], "two")

    def test_attempt_limit_prevents_infinite_retry(self):
        job = self.submit()
        for _ in range(3):
            self.claim()
            self.expire(job["id"])
        self.assertEqual(self.request("POST", "/v1/jobs/claim", WORKER, {})[0], 204)
        _, stored = self.request("GET", f"/v1/jobs/{job['id']}", ADMIN)
        self.assertEqual(stored["status"], "failed")
        self.assertEqual(stored["attempts"], 3)
        self.assertIn("expired", stored["stderr"])

    def test_other_worker_cannot_renew_or_complete_job(self):
        job = self.submit()
        claimed = self.claim()
        body = {"lease_token": claimed["lease_token"], "exit_code": 0}
        for action in ("heartbeat", "result"):
            self.assertEqual(self.request("POST", f"/v1/jobs/{job['id']}/{action}", OTHER, body)[0], 409)

    def test_job_validation_rejects_unpinned_and_privileged_options(self):
        for bad in (
            {"image": "debian:latest"}, {"privileged": True}, {"command": []},
            {"command": [""]}, {"command": ["a\x00b"]}, {"command": ["x" * 4097]},
            {"command": ["\ud800"]},
            {"timeout_seconds": True}, {"timeout_seconds": 3601}, {"cpus": True},
            {"cpus": float("nan")}, {"cpus": 10 ** 400}, {"memory_mb": False}, {"gpu": 1},
        ):
            with self.subTest(bad=bad):
                status, _ = self.request("POST", "/v1/jobs", ADMIN,
                    {"image": IMAGE, "command": ["echo", "hello"], **bad})
                self.assertEqual(status, 400)

    def test_result_size_and_exit_code_validation(self):
        job = self.submit()
        claimed = self.claim()
        for bad in ({"exit_code": True}, {"stdout": "x" * 65537}, {"stderr": ["x"]},
                    {"stdout": "\ud800"}, {"stderr": "\udfff"}):
            status, _ = self.request("POST", f"/v1/jobs/{job['id']}/result", WORKER,
                {"lease_token": claimed["lease_token"], "exit_code": 0, **bad})
            self.assertEqual(status, 400)

    def test_jobs_survive_store_reopening(self):
        job = self.submit()
        reopened = Store(self.config)
        self.assertEqual(reopened.list_jobs(job["id"])["status"], "queued")

    def test_job_list_contains_summaries_while_detail_retains_results(self):
        job = self.submit()
        claimed = self.claim()
        self.request("POST", f"/v1/jobs/{job['id']}/result", WORKER,
                     {"lease_token": claimed["lease_token"], "exit_code": 0,
                      "stdout": "x" * 65536, "stderr": "diagnostic"})
        status, listing = self.request("GET", "/v1/jobs", ADMIN)
        self.assertEqual(status, 200)
        summary = listing["jobs"][0]
        self.assertEqual(summary["id"], job["id"])
        for key in ("command", "stdout", "stderr"):
            self.assertNotIn(key, summary)
        _, detail = self.request("GET", f"/v1/jobs/{job['id']}", ADMIN)
        self.assertEqual(detail["stdout"], "x" * 65536)
        self.assertEqual(detail["command"], ["echo", "hello"])

    def test_duplicate_length_and_short_body_are_rejected(self):
        for content_headers, body in (("Content-Length: 2\r\nContent-Length: 2\r\n", b"{}"),
                                      ("Content-Length: 10\r\n", b"{}")):
            raw = ("POST /v1/jobs/claim HTTP/1.0\r\nHost: localhost\r\n"
                   f"Authorization: Bearer {WORKER}\r\n{content_headers}\r\n").encode() + body
            with socket.create_connection(("127.0.0.1", self.server.server_port), timeout=3) as connection:
                connection.sendall(raw)
                connection.shutdown(socket.SHUT_WR)
                response = b""
                while chunk := connection.recv(8192):
                    response += chunk
            self.assertEqual(response.split(b" ", 2)[1], b"400")


class ConfigTests(unittest.TestCase):
    def test_relative_database_and_distinct_credentials(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.json"
            data = dict(database="state/jobs.db", admin_token=ADMIN,
                        workers={"one": WORKER}, allowed_images=[IMAGE])
            path.write_text(json.dumps(data))
            path.chmod(0o600)
            self.assertEqual(Config.load(path).database, path.parent / "state/jobs.db")
            data["workers"]["one"] = ADMIN
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                Config.load(path)

    def test_secret_configuration_rejects_group_or_world_access(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.json"
            path.write_text(json.dumps(dict(database="jobs.db", admin_token=ADMIN,
                                            workers={"one": WORKER}, allowed_images=[IMAGE])))
            for mode in (0o640, 0o604, 0o644):
                path.chmod(mode)
                with self.subTest(mode=mode), self.assertRaisesRegex(ValueError, "chmod 600"):
                    Config.load(path)
            path.chmod(0o600)
            self.assertEqual(Config.load(path).admin_token, ADMIN)

    def test_secret_configuration_size_and_token_validation(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "config.json"
            data = dict(database="jobs.db", admin_token=ADMIN,
                        workers={"one": WORKER}, allowed_images=[IMAGE])
            path.write_text(json.dumps(data))
            path.chmod(0o600)
            for token in ("x" * 23, "x" * 1018, "a" * 24 + " ", "a" * 24 + "\n",
                          "a" * 24 + "\u00ff", "a" * 24 + "\x00"):
                data["admin_token"] = token
                path.write_text(json.dumps(data))
                with self.subTest(token_length=len(token)), self.assertRaises(ValueError):
                    Config.load(path)
            data["admin_token"] = "x" * 1017
            path.write_text(json.dumps(data))
            self.assertEqual(Config.load(path).admin_token, "x" * 1017)
            data["lease_seconds"] = 10 ** 400
            path.write_text(json.dumps(data))
            with self.assertRaises(ValueError):
                Config.load(path)
            path.write_text(" " * (256 * 1024 + 1))
            with self.assertRaisesRegex(ValueError, "256 KiB"):
                Config.load(path)


if __name__ == "__main__":
    unittest.main()
