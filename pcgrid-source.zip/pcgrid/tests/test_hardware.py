from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from pcgrid import hardware


class HardwareTests(unittest.TestCase):
    def power_device(self, root, name, kind, online=None):
        device = root / name
        device.mkdir()
        (device / "type").write_text(kind)
        if online is not None:
            (device / "online").write_text(online)

    def test_missing_or_battery_only_power_information_is_unknown(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.assertIsNone(hardware.read_ac_power(root / "missing"))
            self.assertIsNone(hardware.read_ac_power(root))
            self.power_device(root, "BAT0", "Battery", "1")
            self.assertIsNone(hardware.read_ac_power(root))

    def test_known_offline_and_online_ac(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.power_device(root, "AC", "Mains", "0")
            self.assertIs(hardware.read_ac_power(root), False)
            (root / "AC" / "online").write_text("1")
            self.assertIs(hardware.read_ac_power(root), True)

    def test_online_usb_power_overrides_an_offline_other_adapter(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.power_device(root, "AC", "Mains", "0")
            self.power_device(root, "PD", "USB_PD", "1")
            self.assertIs(hardware.read_ac_power(root), True)

    def test_unreadable_or_invalid_online_value_never_grants_power(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            self.power_device(root, "AC", "Mains", "unknown")
            self.assertIsNone(hardware.read_ac_power(root))
            (root / "AC" / "online").unlink()
            self.assertIsNone(hardware.read_ac_power(root))

    def test_gpu_inventory_distinguishes_vendors_and_excludes_audio(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name, vendor, kind in (("00:01.0", "0x8086", "0x030000"),
                                       ("00:02.0", "0x1002", "0x038000"),
                                       ("00:03.0", "0x10de", "0x030200"),
                                       ("00:03.1", "0x10de", "0x040300")):
                device = root / name
                device.mkdir()
                (device / "vendor").write_text(vendor)
                (device / "class").write_text(kind)
                (device / "device").write_text("0x1234")
            adapters = hardware.display_adapters(root)
            self.assertEqual([item["vendor"] for item in adapters], ["Intel", "AMD", "NVIDIA"])
            self.assertEqual(adapters[-1]["device_id"], "10de:1234")

    def test_nvidia_inventory_reports_model_driver_and_dedicated_memory(self):
        result = SimpleNamespace(returncode=0, stdout='"NVIDIA GeForce RTX 3050 Laptop GPU", 595.112.07, 4096\n')
        with patch.object(hardware.subprocess, "run", return_value=result) as run:
            devices = hardware.nvidia_driver_devices()
        self.assertEqual(devices[0]["dedicated_memory_mb"], 4096)
        self.assertIn("RTX 3050", devices[0]["name"])
        self.assertNotIn("uuid", str(run.call_args))
        self.assertNotIn("serial", str(run.call_args))

    def test_missing_nvidia_driver_does_not_mark_intel_as_cuda_capable(self):
        with patch.object(hardware, "display_adapters", return_value=[{"vendor": "Intel"}]), \
             patch.object(hardware, "nvidia_driver_devices", return_value=[]), \
             patch.object(hardware, "read_ac_power", return_value=True):
            report = hardware.report()
        self.assertEqual(report["driver_detected_backends"], ["cpu"])
        self.assertIn("Not implemented", report["intel_amd_acceleration"])

    def test_nvidia_probe_failure_and_timeout_return_no_devices(self):
        for error in (FileNotFoundError(), subprocess.TimeoutExpired("nvidia-smi", 5)):
            with patch.object(hardware.subprocess, "run", side_effect=error):
                self.assertEqual(hardware.nvidia_driver_devices(), [])


if __name__ == "__main__":
    unittest.main()
