import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest

from pcgrid import manage
from pcgrid.worker import WorkerError


class ManageTests(unittest.TestCase):
    def test_unique_private_credentials_and_no_overwrite(self):
        image = "docker.io/library/debian@sha256:" + "a" * 64
        with tempfile.TemporaryDirectory() as directory:
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                manage.main(["init", "--directory", directory, "--image", image])
                manage.main(["add-worker", "--directory", directory, "--id", "pc1", "--gpu"])
                manage.main(["add-worker", "--directory", directory, "--id", "pc2"])
            config = json.loads((Path(directory) / "coordinator.json").read_text())
            pc1 = json.loads((Path(directory) / "pc1.json").read_text())
            self.assertNotEqual(config["admin_token"], pc1["worker_token"])
            self.assertNotEqual(config["workers"]["pc1"], config["workers"]["pc2"])
            self.assertEqual(pc1["worker_token"], config["workers"]["pc1"])
            self.assertTrue(pc1["gpu_enabled"])
            self.assertNotIn(pc1["worker_token"], output.getvalue())
            for file in Path(directory).glob("*.json"):
                self.assertEqual(file.stat().st_mode & 0o777, 0o600)
            with self.assertRaises(ValueError):
                manage.main(["add-worker", "--directory", directory, "--id", "pc1"])
            with self.assertRaises(FileExistsError):
                manage.main(["init", "--directory", directory, "--image", image])

    def test_invalid_remote_worker_configuration_is_not_written(self):
        image = "docker.io/library/debian@sha256:" + "a" * 64
        with tempfile.TemporaryDirectory() as directory:
            with contextlib.redirect_stdout(io.StringIO()):
                manage.main(["init", "--directory", directory, "--image", image])
            with self.assertRaises(WorkerError):
                manage.main(["add-worker", "--directory", directory, "--id", "remote",
                             "--url", "http://example.com"])
            self.assertFalse((Path(directory) / "remote.json").exists())
            config = manage.load(Path(directory) / "coordinator.json")
            self.assertEqual(config["workers"], {})


if __name__ == "__main__":
    unittest.main()
