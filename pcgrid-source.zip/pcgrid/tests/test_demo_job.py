import contextlib
import ctypes as ct
import importlib.util
import io
import json
from pathlib import Path
import unittest
from unittest.mock import Mock, patch


spec = importlib.util.spec_from_file_location(
    "pcgrid_startup_job", Path(__file__).resolve().parents[1] / "examples/startup_job/job.py")
job = importlib.util.module_from_spec(spec)
spec.loader.exec_module(job)


def execute(mode, **kwargs):
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        code = job.main(mode, **kwargs)
    return code, [json.loads(line) for line in output.getvalue().splitlines()], output.getvalue()


class DemoJobTests(unittest.TestCase):
    def test_cpu_math_verifies_expected_vector_and_closed_form_checksum(self):
        code, events, raw = execute("cpu", pause=0)
        self.assertEqual(code, 0)
        self.assertEqual(events[0]["event"], "START")
        self.assertEqual([event["round"] for event in events if event["event"] == "PROGRESS"],
                         [1, 2, 3, 4, 5])
        self.assertEqual(events[-1]["event"], "PASS")
        self.assertEqual(events[-1]["checksum"], 67_043_328)
        self.assertEqual(events[-1]["mode"], "cpu")
        self.assertIn("does not validate a GPU", events[-1]["device"])
        self.assertLess(len(raw.encode()), 8192)

    def test_corrupt_values_and_short_vectors_fail_verification(self):
        left, right = job.inputs(1024)
        correct = [a + b for a, b in zip(left, right)]
        self.assertEqual(job.verify(correct, 1024), 1_047_552)
        correct[17] += 1
        with self.assertRaisesRegex(job.DemoError, "element 17"):
            job.verify(correct, 1024)
        with self.assertRaisesRegex(job.DemoError, "length"):
            job.verify(correct[:-1], 1024)

    def test_corrupt_result_is_terminal_failure_not_pass(self):
        with patch.object(job, "verify", side_effect=job.DemoError("Injected bad result")):
            code, events, _ = execute("cpu", elements=1024, pause=0)
        self.assertEqual(code, 1)
        self.assertEqual(events[-1]["event"], "FAIL")
        self.assertNotIn("PASS", [event["event"] for event in events])

    def test_gpu_mode_missing_driver_fails_without_cpu_fallback(self):
        with patch.object(job.ct, "CDLL", side_effect=OSError("No libcuda")):
            code, events, _ = execute("gpu", pause=0)
        self.assertEqual(code, 1)
        self.assertEqual(events[-1]["event"], "FAIL")
        self.assertEqual(events[-1]["mode"], "gpu")
        self.assertIn("no CPU fallback", events[-1]["error"])
        self.assertNotIn("PASS", [event["event"] for event in events])

    def test_gpu_api_error_is_terminal_failure(self):
        fake = type("BrokenGpu", (), {
            "__enter__": lambda self: (_ for _ in ()).throw(job.DemoError("cuInit: CUDA_ERROR_NO_DEVICE")),
            "__exit__": lambda *args: None,
        })()
        with patch.object(job, "CudaVector", return_value=fake):
            code, events, _ = execute("gpu", pause=0)
        self.assertEqual(code, 1)
        self.assertIn("CUDA_ERROR_NO_DEVICE", events[-1]["error"])
        self.assertNotIn("PASS", [event["event"] for event in events])

    def test_parameter_bounds_reject_unbounded_work(self):
        cases = [dict(elements=0), dict(elements=65537), dict(elements=True),
                 dict(rounds=0), dict(rounds=6), dict(rounds=True),
                 dict(pause=float("inf")), dict(pause=float("nan")), dict(pause=1)]
        for kwargs in cases:
            with self.subTest(kwargs=kwargs):
                code, events, _ = execute("cpu", **kwargs)
                self.assertEqual(code, 1)
                self.assertEqual(events[-1]["event"], "FAIL")

    def test_real_gpu_allocations_have_bounded_data_size(self):
        left, right = job.inputs(job.ELEMENTS)
        self.assertEqual(ct.sizeof(left), 262144)
        self.assertLess(ct.sizeof(left) * 3, 1024 * 1024)

    def test_cleanup_attempts_all_resources_even_if_one_free_fails(self):
        gpu = object.__new__(job.CudaVector)
        gpu.context = ct.c_void_p(10)
        gpu.module = ct.c_void_p(20)
        gpu.addresses = [ct.c_uint64(30), ct.c_uint64(40)]
        gpu.call = Mock(side_effect=[job.DemoError("free failed"), None, None, None])
        with self.assertRaisesRegex(job.DemoError, "cleanup failed"):
            gpu.close()
        self.assertEqual([entry.args[0] for entry in gpu.call.call_args_list],
                         ["cuMemFree_v2", "cuMemFree_v2", "cuModuleUnload", "cuCtxDestroy_v2"])
        self.assertEqual(gpu.addresses, [])
        self.assertIsNone(gpu.context.value)
        self.assertIsNone(gpu.module.value)


if __name__ == "__main__":
    unittest.main()
