import contextlib
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

from pcgrid import demo, manage
from pcgrid.coordinator import Config, Coordinator, Store
from pcgrid.worker import WorkerError, validate_config, validate_job


class DemoTests(unittest.TestCase):
    def test_source_chunks_preserve_unicode_and_protocol_limits(self):
        source = ("a" * 3499 + "\U0001f600") * 4
        chunks = demo.source_chunks(source)
        self.assertEqual("".join(chunks), source)
        self.assertTrue(all(len(chunk.encode()) <= 3500 for chunk in chunks))

    def test_payload_is_accepted_by_both_coordinator_and_existing_worker(self):
        with tempfile.TemporaryDirectory() as directory:
            config = Config(Path(directory) / "jobs.db", "admin-" + "a" * 32,
                            {"worker": "worker-" + "b" * 32}, (demo.DEMO_IMAGE,))
            store = Store(config)
            worker = validate_config({"coordinator_url": "http://127.0.0.1:8080",
                                      "worker_token": "worker-" + "b" * 32,
                                      "allowed_images": [demo.DEMO_IMAGE], "gpu_enabled": True})
            for mode in ("cpu", "gpu"):
                spec = demo.job_spec(mode)
                self.assertEqual(spec["gpu"], mode == "gpu")
                self.assertTrue(all(len(arg.encode()) <= 4096 for arg in spec["command"]))
                self.assertLess(sum(len(arg.encode()) for arg in spec["command"]), 32768)
                accepted = store.submit(spec)
                validate_job({**spec, "id": accepted["id"], "lease_token": "test-lease"}, worker)

    def test_transported_source_runs_and_returns_verified_cpu_result(self):
        command = demo.job_spec("cpu")["command"]
        result = subprocess.run([sys.executable, *command[1:]], text=True, capture_output=True, timeout=15)
        self.assertEqual(result.returncode, 0, result.stderr)
        events = [json.loads(line) for line in result.stdout.splitlines()]
        self.assertEqual(events[-1]["event"], "PASS")
        self.assertEqual(events[-1]["checksum"], 67_043_328)
        self.assertEqual(events[-1]["mode"], "cpu")

    def test_prepare_private_credentials_survive_directory_move_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "demo"
            output = io.StringIO()
            with contextlib.redirect_stdout(output):
                demo.main(["prepare", "--directory", str(target), "--gpu"])
            config = Config.load(target / "coordinator.json")
            worker = manage.load(target / "startup-worker.json")
            self.assertEqual(config.database, target / "jobs.sqlite3")
            self.assertEqual(config.workers["startup-worker"], worker["worker_token"])
            self.assertNotEqual(config.admin_token, worker["worker_token"])
            self.assertNotIn(worker["worker_token"], output.getvalue())
            self.assertTrue(worker["gpu_enabled"])
            self.assertEqual(worker["allowed_images"], [demo.DEMO_IMAGE])
            for path in target.glob("*.json"):
                self.assertEqual(path.stat().st_mode & 0o777, 0o600)
            before = (target / "coordinator.json").read_bytes()
            with self.assertRaises(ValueError):
                demo.prepare(target)
            self.assertEqual((target / "coordinator.json").read_bytes(), before)

    def test_prepare_rejects_remote_plaintext_before_creating_files(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "demo"
            with self.assertRaises(WorkerError):
                demo.prepare(target, worker_url="http://192.168.1.10:8080")
            self.assertFalse(target.exists())

    def test_default_worker_url_tracks_custom_port(self):
        with tempfile.TemporaryDirectory() as directory:
            _, worker_path = demo.prepare(Path(directory) / "demo", port=9090)
            self.assertEqual(manage.load(worker_path)["coordinator_url"], "http://127.0.0.1:9090")

    def test_laptop_profiles_limit_resources_and_require_ac_power(self):
        with tempfile.TemporaryDirectory() as directory:
            for profile, gpu in (("laptop-cpu", False), ("laptop-nvidia", True)):
                _, worker_path = demo.prepare(Path(directory) / profile, profile=profile)
                config = manage.load(worker_path)
                self.assertEqual(config["gpu_enabled"], gpu)
                self.assertTrue(config["require_ac_power"])
                self.assertEqual(config["max_cpus"], 1)
                self.assertEqual(config["max_memory_mb"], 1024)
                self.assertGreaterEqual(config["max_timeout_seconds"], demo.job_spec()["timeout_seconds"])

    def test_cpu_laptop_profile_cannot_silently_enable_gpu(self):
        with tempfile.TemporaryDirectory() as directory:
            target = Path(directory) / "demo"
            with self.assertRaises(ValueError):
                demo.prepare(target, profile="laptop-cpu", gpu=True)
            self.assertFalse(target.exists())

    def test_worker_terminal_control_sequences_are_escaped(self):
        output = demo.safe_output('hello\x1b[31m\r\u202e\n{"event":"PASS"}')
        self.assertNotIn("\x1b", output)
        self.assertNotIn("\r", output)
        self.assertNotIn("\u202e", output)
        self.assertIn('\\x1b[31m', output)
        self.assertIn('\n{"event":"PASS"}', output)

    def test_queue_default_admin_url_tracks_custom_port(self):
        with tempfile.TemporaryDirectory() as directory:
            config, _ = demo.prepare(Path(directory) / "demo", port=9090)
            with patch.object(manage, "request", return_value={"id": "queued-test"}) as request:
                with contextlib.redirect_stdout(io.StringIO()):
                    demo.main(["queue", "--config", str(config)])
            self.assertEqual(request.call_args.args[0], "http://127.0.0.1:9090/v1/jobs")

    def test_queue_uses_authenticated_api_and_waits_for_a_worker(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)
            config = Config(path / "jobs.db", "admin-" + "a" * 32,
                            {"worker": "worker-" + "b" * 32}, (demo.DEMO_IMAGE,), port=0)
            manage.write_private(path / "config.json", {
                "admin_token": config.admin_token, "allowed_images": [demo.DEMO_IMAGE]})
            with Coordinator(config) as server:
                thread = threading.Thread(target=server.serve_forever, daemon=True)
                thread.start()
                try:
                    with contextlib.redirect_stdout(io.StringIO()):
                        demo.main(["queue", "--config", str(path / "config.json"), "--mode", "gpu",
                                   "--url", f"http://127.0.0.1:{server.server_port}"])
                    queued = server.store.list_jobs()["jobs"]
                    self.assertEqual(len(queued), 1)
                    self.assertEqual(queued[0]["status"], "queued")
                    self.assertTrue(queued[0]["gpu"])
                finally:
                    server.shutdown()
                    thread.join()

    def test_unapproved_image_is_not_silently_enabled(self):
        with tempfile.TemporaryDirectory() as directory:
            config = Path(directory) / "config.json"
            manage.write_private(config, {"admin_token": "admin-" + "a" * 32,
                                         "allowed_images": ["debian@sha256:" + "a" * 64]})
            before = config.read_bytes()
            with patch.object(manage, "request") as request:
                with self.assertRaises(ValueError):
                    demo.main(["queue", "--config", str(config)])
                request.assert_not_called()
            self.assertEqual(config.read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
